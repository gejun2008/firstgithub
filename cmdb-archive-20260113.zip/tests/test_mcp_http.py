"""Streamable HTTP transport tests"""

import json

import anyio
import httpx
import pytest
from mcp.client.session import ClientSession
from mcp.client.sse import sse_client
from mcp.shared._httpx_utils import MCP_DEFAULT_SSE_READ_TIMEOUT, MCP_DEFAULT_TIMEOUT

from app.mcp import server as mcp_server_module
from app.mcp.http_server import http_app
from app.repositories.product_repository import ProductRepository


def _asgi_client_factory(app):
    """Create an httpx AsyncClient factory bound to the given ASGI app."""
    asgi_transport = httpx.ASGITransport(app=app)

    def factory(headers=None, timeout=None, auth=None):
        return httpx.AsyncClient(
            transport=asgi_transport,
            base_url="http://testserver",
            headers=headers,
            timeout=timeout
            or httpx.Timeout(MCP_DEFAULT_TIMEOUT, read=MCP_DEFAULT_SSE_READ_TIMEOUT),
            follow_redirects=True,
            auth=auth,
        )

    return factory


@pytest.mark.asyncio
async def test_streamable_http_list_tools(db_session, monkeypatch):
    """Ensure SSE transport exposes available tools."""
    monkeypatch.setattr(mcp_server_module, "get_db_session", lambda: db_session)

    client_factory = _asgi_client_factory(http_app)

    async with sse_client(
        "http://testserver/sse",
        httpx_client_factory=client_factory,
    ) as (read_stream, write_stream):
        session = ClientSession(read_stream, write_stream)
        async with anyio.fail_after(10):
            init_result = await session.initialize()
        assert init_result.capabilities is not None

        async with anyio.fail_after(10):
            tools_result = await session.list_tools()
        tool_names = {tool.name for tool in tools_result.tools}
        assert "get_product" in tool_names


@pytest.mark.asyncio
async def test_streamable_http_call_tool(db_session, sample_product_data, monkeypatch):
    """Round-trip a tool call over SSE transport."""
    monkeypatch.setattr(mcp_server_module, "get_db_session", lambda: db_session)

    # Seed data so the tool can fetch it
    repo = ProductRepository(db_session)
    created = repo.create(**sample_product_data)

    client_factory = _asgi_client_factory(http_app)

    async with sse_client(
        "http://testserver/sse",
        httpx_client_factory=client_factory,
    ) as (read_stream, write_stream):
        session = ClientSession(read_stream, write_stream)
        async with anyio.fail_after(10):
            await session.initialize()

        async with anyio.fail_after(10):
            call_result = await session.call_tool("get_product", {"id": created.id})
        assert call_result.isError is False
        assert call_result.content, "Expected tool response content"

        payload = json.loads(call_result.content[0].text)
        assert payload["id"] == created.id
        assert payload["product_name"] == sample_product_data["product_name"]
