"""GraphQL API测试"""
import pytest
from app.repositories.product_repository import ProductRepository
from app.repositories.service_repository import StandardServiceRepository
from app.api.graphql.schema import Query, get_db_session


def test_graphql_query_products(db_session):
    """测试GraphQL查询产品"""
    # 创建测试数据
    repo = ProductRepository(db_session)
    repo.create(product_id=1, product_name="Test Product")
    
    # 临时替换get_db_session
    import app.api.graphql.schema as schema_module
    original_get_db_session = schema_module.get_db_session
    schema_module.get_db_session = lambda: db_session
    
    try:
        query = Query()
        products = query.products()
        
        assert len(products) > 0
        assert products[0].product_name == "Test Product"
    finally:
        schema_module.get_db_session = original_get_db_session


def test_graphql_query_product_by_id(db_session):
    """测试GraphQL根据ID查询产品"""
    repo = ProductRepository(db_session)
    created = repo.create(product_id=1, product_name="Test Product")
    
    import app.api.graphql.schema as schema_module
    original_get_db_session = schema_module.get_db_session
    schema_module.get_db_session = lambda: db_session
    
    try:
        query = Query()
        product = query.product(id=created.id)
        
        assert product is not None
        assert product.product_name == "Test Product"
    finally:
        schema_module.get_db_session = original_get_db_session


def test_graphql_query_service_with_redis_config(db_session, sample_redis_config):
    """测试GraphQL查询带Redis配置的服务"""
    repo = StandardServiceRepository(db_session)
    created = repo.create(
        service_id=1,
        service_name="Redis Service",
        component_id=1,
        service_type="redis",
        deployment_info=sample_redis_config
    )
    
    import app.api.graphql.schema as schema_module
    original_get_db_session = schema_module.get_db_session
    schema_module.get_db_session = lambda: db_session
    
    try:
        query = Query()
        service = query.standard_service(id=created.id)
        
        assert service is not None
        assert service.service_name == "Redis Service"
        # 验证配置类型解析
        assert service.deployment_info is not None
    finally:
        schema_module.get_db_session = original_get_db_session


def test_graphql_query_service_with_nebula_config(db_session, sample_nebula_config):
    """测试GraphQL查询带Nebula配置的服务"""
    repo = StandardServiceRepository(db_session)
    created = repo.create(
        service_id=2,
        service_name="Nebula Service",
        component_id=1,
        service_type="nebula",
        deployment_info=sample_nebula_config
    )
    
    import app.api.graphql.schema as schema_module
    original_get_db_session = schema_module.get_db_session
    schema_module.get_db_session = lambda: db_session
    
    try:
        query = Query()
        service = query.standard_service(id=created.id)
        
        assert service is not None
        assert service.service_name == "Nebula Service"
        assert service.deployment_info is not None
    finally:
        schema_module.get_db_session = original_get_db_session

