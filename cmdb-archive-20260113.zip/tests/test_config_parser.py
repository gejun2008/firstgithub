"""配置解析器测试"""
import pytest
from app.services.config_parser import ConfigParser
from app.core.exceptions import ConfigValidationError


def test_validate_redis_config(sample_redis_config):
    """测试Redis配置验证"""
    result = ConfigParser.validate_config(sample_redis_config, product_type="redis")
    assert result["hostname"] == "redis9001.eniot.io"
    assert result["user"] == "root"
    assert len(result["forbidden_keywords"]) == 4


def test_validate_nebula_config(sample_nebula_config):
    """测试Nebula配置验证"""
    result = ConfigParser.validate_config(sample_nebula_config, product_type="nebula")
    assert result["hostname"] == "nebula-graph9001.eniot.io"
    assert result["port"] == "9669"
    assert len(result["service_names"]) == 3


def test_validate_invalid_config():
    """测试无效配置验证"""
    invalid_config = {
        "hostname": "test",
        # 缺少必需字段
    }
    with pytest.raises(ConfigValidationError):
        ConfigParser.validate_config(invalid_config, product_type="redis")


def test_validate_default_config():
    """测试默认配置验证"""
    config = {"key1": "value1", "key2": 123}
    result = ConfigParser.validate_config(config, product_type="unknown")
    assert "key1" in result
    assert result["key1"] == "value1"
    assert result["key2"] == 123


def test_parse_deployment_info_none():
    """测试解析None的deployment_info"""
    result = ConfigParser.parse_deployment_info(None)
    assert result is None


def test_parse_deployment_info_redis(sample_redis_config):
    """测试解析Redis deployment_info"""
    result = ConfigParser.parse_deployment_info(sample_redis_config, service_type="redis")
    assert result is not None
    assert result["hostname"] == "redis9001.eniot.io"


def test_parse_deployment_info_nebula(sample_nebula_config):
    """测试解析Nebula deployment_info"""
    result = ConfigParser.parse_deployment_info(sample_nebula_config, service_type="nebula")
    assert result is not None
    assert "port" in result
    assert "service_names" in result

