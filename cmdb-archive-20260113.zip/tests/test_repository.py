"""Repository层测试"""
import pytest
from app.repositories.product_repository import ProductRepository
from app.models.product import Product


def test_product_repository_create(db_session, sample_product_data):
    """测试创建产品"""
    repo = ProductRepository(db_session)
    product = repo.create(**sample_product_data)
    
    assert product.id is not None
    assert product.product_id == 1
    assert product.product_name == "Test Product"


def test_product_repository_get_by_id(db_session, sample_product_data):
    """测试根据ID获取产品"""
    repo = ProductRepository(db_session)
    created = repo.create(**sample_product_data)
    
    found = repo.get_by_id(created.id)
    assert found is not None
    assert found.product_id == 1


def test_product_repository_get_by_product_id(db_session, sample_product_data):
    """测试根据product_id获取产品"""
    repo = ProductRepository(db_session)
    repo.create(**sample_product_data)
    
    found = repo.get_by_product_id(1)
    assert found is not None
    assert found.product_name == "Test Product"


def test_product_repository_update(db_session, sample_product_data):
    """测试更新产品"""
    repo = ProductRepository(db_session)
    created = repo.create(**sample_product_data)
    
    updated = repo.update(created.id, product_name="Updated Product")
    assert updated.product_name == "Updated Product"


def test_product_repository_delete(db_session, sample_product_data):
    """测试删除产品"""
    repo = ProductRepository(db_session)
    created = repo.create(**sample_product_data)
    
    result = repo.delete(created.id)
    assert result is True
    
    found = repo.get_by_id(created.id)
    assert found is None


def test_product_repository_get_all(db_session):
    """测试获取所有产品"""
    repo = ProductRepository(db_session)
    
    # 创建多个产品
    for i in range(5):
        repo.create(
            product_id=i + 1,
            product_name=f"Product {i + 1}"
        )
    
    all_products = repo.get_all()
    assert len(all_products) == 5

