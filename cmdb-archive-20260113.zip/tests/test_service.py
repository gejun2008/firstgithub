"""Service层测试"""
import pytest
from app.services.product_service import ProductService
from app.services.service_service import StandardServiceService, DeployServiceService
from app.core.exceptions import NotFoundError
from app.models.product import Product


def test_product_service_create(db_session, sample_product_data):
    """测试创建产品服务"""
    service = ProductService(db_session)
    product = service.create(**sample_product_data)
    
    assert product.id is not None
    assert product.product_id == 1


def test_product_service_get_by_id(db_session, sample_product_data):
    """测试根据ID获取产品"""
    service = ProductService(db_session)
    created = service.create(**sample_product_data)
    
    found = service.get_by_id(created.id)
    assert found.product_id == 1


def test_product_service_get_by_id_not_found(db_session):
    """测试获取不存在的产品"""
    service = ProductService(db_session)
    with pytest.raises(NotFoundError):
        service.get_by_id(999)


def test_product_service_create_duplicate(db_session, sample_product_data):
    """测试创建重复product_id的产品"""
    service = ProductService(db_session)
    service.create(**sample_product_data)
    
    with pytest.raises(ValueError):
        service.create(**sample_product_data)


def test_standard_service_create_with_redis_config(db_session, sample_redis_config):
    """测试创建带Redis配置的标准服务"""
    service = StandardServiceService(db_session)
    svc = service.create(
        service_id=1,
        service_name="Redis Service",
        component_id=1,
        service_type="redis",
        deployment_info=sample_redis_config
    )
    
    assert svc.id is not None
    assert svc.deployment_info is not None
    assert svc.deployment_info["hostname"] == "redis9001.eniot.io"


def test_standard_service_create_with_nebula_config(db_session, sample_nebula_config):
    """测试创建带Nebula配置的标准服务"""
    service = StandardServiceService(db_session)
    svc = service.create(
        service_id=2,
        service_name="Nebula Service",
        component_id=1,
        service_type="nebula",
        deployment_info=sample_nebula_config
    )
    
    assert svc.id is not None
    assert svc.deployment_info is not None
    assert "port" in svc.deployment_info
    assert "service_names" in svc.deployment_info


def test_standard_service_create_with_invalid_config(db_session):
    """测试创建带无效配置的服务"""
    service = StandardServiceService(db_session)
    invalid_config = {"hostname": "test"}  # 缺少必需字段
    
    with pytest.raises(Exception):  # 应该抛出ConfigValidationError
        service.create(
            service_id=3,
            service_name="Invalid Service",
            component_id=1,
            service_type="redis",
            deployment_info=invalid_config
        )


def test_deploy_service_create_with_config(db_session, sample_redis_config):
    """测试创建带配置的部署服务"""
    service = DeployServiceService(db_session)
    svc = service.create(
        service_id=1,
        service_name="Deploy Redis",
        region_id=1,
        component_id=1,
        service_type="redis",
        deployment_info=sample_redis_config
    )
    
    assert svc.id is not None
    assert svc.deployment_info is not None

