"""测试配置和fixtures"""
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.core.database import Base, get_db
from app.models import *  # 导入所有模型


# 使用SQLite内存数据库进行测试
TEST_DATABASE_URL = "sqlite:///:memory:"


@pytest.fixture(scope="function")
def db_session():
    """创建测试数据库会话"""
    engine = create_engine(TEST_DATABASE_URL, connect_args={"check_same_thread": False})
    # 先删除所有表（如果存在）
    Base.metadata.drop_all(bind=engine)
    # 再创建所有表
    Base.metadata.create_all(bind=engine)
    TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture
def sample_product_data():
    """示例产品数据"""
    return {
        "product_id": 1,
        "product_name": "Test Product",
        "product_version": "1.0.0",
        "product_desc": "Test product description"
    }


@pytest.fixture
def sample_redis_config():
    """示例Redis配置"""
    return {
        "hostname": "redis9001.eniot.io",
        "user": "root",
        "bin_path": "/usr/local/redis/bin",
        "config_dir": "/data1/redis/7000/conf",
        "log_dir": "/data1/redis/7000/log",
        "forbidden_keywords": ["flushall", "flushdb", "del", "shutdown"]
    }


@pytest.fixture
def sample_nebula_config():
    """示例Nebula配置"""
    return {
        "hostname": "nebula-graph9001.eniot.io",
        "user": "root",
        "bin_path": "/usr/local/nebula-3.1.0/bin",
        "config_dir": "/usr/local/nebula-3.1.0/etc",
        "log_dir": "/data1/nebula/logs",
        "port": "9669",
        "service_names": ["nebula-graphd", "nebula-storaged", "nebula-metad"],
        "forbidden_keywords": ["drop", "delete", "clear", "remove"]
    }

