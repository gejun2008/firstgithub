"""
MCP SSE 测试客户端
用于测试 MCP HTTP Server 的 SSE 连接和功能
"""

import asyncio
import json
from typing import Any, Dict

import httpx


class MCPSSEClient:
    """MCP SSE 客户端"""

    def __init__(self, base_url: str = "http://localhost:8001"):
        self.base_url = base_url
        self.sse_url = f"{base_url}/sse"
        self.request_id = 0

    def _next_id(self) -> int:
        """获取下一个请求 ID"""
        self.request_id += 1
        return self.request_id

    async def check_health(self) -> Dict[str, Any]:
        """检查服务器健康状态"""
        async with httpx.AsyncClient() as client:
            response = await client.get(f"{self.base_url}/health")
            response.raise_for_status()
            return response.json()

    async def get_server_info(self) -> Dict[str, Any]:
        """获取服务器信息"""
        async with httpx.AsyncClient() as client:
            response = await client.get(self.base_url)
            response.raise_for_status()
            return response.json()

    async def initialize(self) -> Dict[str, Any]:
        """发送初始化请求"""
        message = {
            "jsonrpc": "2.0",
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "mcp-sse-test-client", "version": "1.0.0"},
            },
            "id": self._next_id(),
        }

        return await self._send_request(message)

    async def list_tools(self) -> Dict[str, Any]:
        """列出所有可用工具"""
        message = {
            "jsonrpc": "2.0",
            "method": "tools/list",
            "params": {},
            "id": self._next_id(),
        }

        return await self._send_request(message)

    async def call_tool(
        self, tool_name: str, arguments: Dict[str, Any]
    ) -> Dict[str, Any]:
        """调用工具"""
        message = {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {"name": tool_name, "arguments": arguments},
            "id": self._next_id(),
        }

        return await self._send_request(message)

    async def _send_request(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """发送 JSON-RPC 请求到 SSE 端点"""
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                self.sse_url,
                json=message,
                headers={
                    "Content-Type": "application/json",
                    "Accept": "text/event-stream",
                },
            )
            response.raise_for_status()

            # 解析 SSE 响应
            return self._parse_sse_response(response.text)

    def _parse_sse_response(self, text: str) -> Dict[str, Any]:
        """解析 SSE 响应"""
        # SSE 格式: data: {...}\n\n
        lines = text.strip().split("\n")
        for line in lines:
            if line.startswith("data: "):
                data = line[6:]  # 移除 'data: ' 前缀
                try:
                    return json.loads(data)
                except json.JSONDecodeError:
                    continue

        # 如果没有找到 SSE 格式，尝试直接解析为 JSON
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return {"error": "Failed to parse response", "raw": text}


async def main():
    """主测试函数"""
    print("🧪 MCP SSE Client Test\n")

    client = MCPSSEClient()

    # 测试 1: 检查健康状态
    print("1️⃣  Checking server health...")
    try:
        health = await client.check_health()
        print(f"   ✅ Health: {health}")
    except Exception as e:
        print(f"   ❌ Health check failed: {e}")
        return

    print()

    # 测试 2: 获取服务器信息
    print("2️⃣  Getting server info...")
    try:
        info = await client.get_server_info()
        print(f"   ✅ Server: {info.get('name')}")
        print(f"   📦 Version: {info.get('version')}")
        print(f"   🔌 Transport: {info.get('transport')}")
        print(f"   🌐 Protocol: {info.get('protocol')}")
        print(f"   🔗 Endpoint: {info.get('endpoint')}")
    except Exception as e:
        print(f"   ❌ Failed to get server info: {e}")
        return

    print()

    # 测试 3: 初始化连接
    print("3️⃣  Initializing MCP connection...")
    try:
        init_response = await client.initialize()
        print(f"   ✅ Initialized: {json.dumps(init_response, indent=2)}")
    except Exception as e:
        print(f"   ❌ Initialization failed: {e}")
        print(
            "   💡 This is expected - full SSE implementation requires streaming support"
        )

    print()

    # 测试 4: 列出工具
    print("4️⃣  Listing available tools...")
    try:
        tools_response = await client.list_tools()
        if "result" in tools_response:
            tools = tools_response["result"].get("tools", [])
            print(f"   ✅ Found {len(tools)} tools:")
            for tool in tools[:5]:  # 只显示前 5 个
                print(f"      - {tool.get('name')}: {tool.get('description', 'N/A')}")
            if len(tools) > 5:
                print(f"      ... and {len(tools) - 5} more")
        else:
            print(f"   ⚠️  Unexpected response: {tools_response}")
    except Exception as e:
        print(f"   ❌ Failed to list tools: {e}")
        print(
            "   💡 This is expected - full SSE implementation requires streaming support"
        )

    print()

    # 测试 5: 调用工具示例
    print("5️⃣  Testing tool call (list_products)...")
    try:
        result = await client.call_tool("list_products", {"page": 1, "page_size": 5})
        print(f"   ✅ Tool call result: {json.dumps(result, indent=2)}")
    except Exception as e:
        print(f"   ❌ Tool call failed: {e}")
        print(
            "   💡 This is expected - full SSE implementation requires streaming support"
        )

    print()
    print("=" * 60)
    print("📝 Test Summary:")
    print("   - ✅ Server is running and accessible")
    print("   - ✅ Health check endpoint works")
    print("   - ✅ Server info endpoint works")
    print("   - ⚠️  Full SSE streaming requires proper SSE client")
    print()
    print("💡 To test with a real MCP client:")
    print("   1. Use Cline in VSCode")
    print('   2. Configure with: {"type": "sse", "url": "http://localhost:8001/sse"}')
    print("   3. Or use the official MCP client SDK")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
