"""MCP Server测试"""
import pytest
import json
from typing import Any
from app.mcp.server import mcp_server, call_tool, get_db_session
from app.repositories.product_repository import ProductRepository
from app.repositories.service_repository import StandardServiceRepository, DeployServiceRepository


@pytest.fixture
def sample_product_data():
    """示例产品数据"""
    return {
        "product_id": 1,
        "product_name": "Test Product",
        "product_version": "1.0.0",
        "product_desc": "Test product description"
    }


@pytest.fixture
def sample_redis_config():
    """示例Redis配置"""
    return {
        "hostname": "redis9001.eniot.io",
        "user": "root",
        "bin_path": "/usr/local/redis/bin",
        "config_dir": "/data1/redis/7000/conf",
        "log_dir": "/data1/redis/7000/log",
        "forbidden_keywords": ["flushall", "flushdb", "del", "shutdown"]
    }


@pytest.mark.asyncio
async def test_list_tools():
    """测试列出所有工具"""
    # 直接调用处理函数
    from app.mcp.server import handle_list_tools
    tools = await handle_list_tools()
    assert len(tools) > 0
    tool_names = [tool.name for tool in tools]
    assert "get_product" in tool_names
    assert "list_products" in tool_names
    assert "create_product" in tool_names
    assert "get_standard_service" in tool_names


@pytest.mark.asyncio
async def test_get_product(db_session, sample_product_data, monkeypatch):
    """测试获取产品"""
    # 创建测试数据
    repo = ProductRepository(db_session)
    created = repo.create(**sample_product_data)
    
    # Mock get_db_session 返回测试数据库会话
    from app.mcp import server as mcp_server_module
    monkeypatch.setattr(mcp_server_module, "get_db_session", lambda: db_session)
    
    # 调用MCP工具
    result = await call_tool("get_product", {"id": created.id})
    assert len(result) > 0
    data = json.loads(result[0].text)
    assert "error" not in data, f"Error: {data.get('error')}"
    assert data["id"] == created.id
    assert data["product_name"] == "Test Product"


@pytest.mark.asyncio
async def test_list_products(db_session, monkeypatch):
    """测试列出产品"""
    # 创建测试数据
    repo = ProductRepository(db_session)
    for i in range(3):
        repo.create(product_id=i + 1, product_name=f"Product {i + 1}")
    
    # Mock get_db_session
    from app.mcp import server as mcp_server_module
    monkeypatch.setattr(mcp_server_module, "get_db_session", lambda: db_session)
    
    # 调用MCP工具
    result = await call_tool("list_products", {"skip": 0, "limit": 10})
    assert len(result) > 0
    data = json.loads(result[0].text)
    assert "error" not in data, f"Error: {data.get('error')}"
    assert isinstance(data, list)
    assert len(data) >= 3


@pytest.mark.asyncio
async def test_create_product(db_session, monkeypatch):
    """测试创建产品"""
    # Mock get_db_session
    from app.mcp import server as mcp_server_module
    monkeypatch.setattr(mcp_server_module, "get_db_session", lambda: db_session)
    
    result = await call_tool("create_product", {
        "product_id": 100,
        "product_name": "New Product",
        "product_version": "2.0.0"
    })
    assert len(result) > 0
    data = json.loads(result[0].text)
    assert "error" not in data, f"Error: {data.get('error')}"
    assert "id" in data
    assert data["product_name"] == "New Product"
    assert data["product_id"] == 100


@pytest.mark.asyncio
async def test_update_product(db_session, sample_product_data, monkeypatch):
    """测试更新产品"""
    # 创建测试数据
    repo = ProductRepository(db_session)
    created = repo.create(**sample_product_data)
    
    # Mock get_db_session
    from app.mcp import server as mcp_server_module
    monkeypatch.setattr(mcp_server_module, "get_db_session", lambda: db_session)
    
    # 调用MCP工具更新
    result = await call_tool("update_product", {
        "id": created.id,
        "product_name": "Updated Product"
    })
    assert len(result) > 0
    data = json.loads(result[0].text)
    assert "error" not in data, f"Error: {data.get('error')}"
    assert data["product_name"] == "Updated Product"


@pytest.mark.asyncio
async def test_delete_product(db_session, sample_product_data, monkeypatch):
    """测试删除产品"""
    # 创建测试数据
    repo = ProductRepository(db_session)
    created = repo.create(**sample_product_data)
    
    # Mock get_db_session
    from app.mcp import server as mcp_server_module
    monkeypatch.setattr(mcp_server_module, "get_db_session", lambda: db_session)
    
    # 调用MCP工具删除
    result = await call_tool("delete_product", {"id": created.id})
    assert len(result) > 0
    data = json.loads(result[0].text)
    assert "error" not in data, f"Error: {data.get('error')}"
    assert data["success"] is True


@pytest.mark.asyncio
async def test_get_product_not_found(db_session, monkeypatch):
    """测试获取不存在的产品"""
    # Mock get_db_session
    from app.mcp import server as mcp_server_module
    monkeypatch.setattr(mcp_server_module, "get_db_session", lambda: db_session)
    
    result = await call_tool("get_product", {"id": 99999})
    assert len(result) > 0
    data = json.loads(result[0].text)
    assert "error" in data


@pytest.mark.asyncio
async def test_create_standard_service_with_redis_config(db_session, sample_redis_config, monkeypatch):
    """测试创建带Redis配置的标准服务"""
    # Mock get_db_session
    from app.mcp import server as mcp_server_module
    monkeypatch.setattr(mcp_server_module, "get_db_session", lambda: db_session)
    
    result = await call_tool("create_standard_service", {
        "service_id": 1,
        "service_name": "Redis Service",
        "component_id": 1,
        "service_type": "redis",
        "deployment_info": sample_redis_config
    })
    assert len(result) > 0
    data = json.loads(result[0].text)
    assert "error" not in data, f"Error: {data.get('error')}"
    assert "id" in data
    assert data["service_name"] == "Redis Service"
    assert data["deployment_info"] is not None
    assert data["deployment_info"]["hostname"] == "redis9001.eniot.io"


@pytest.mark.asyncio
async def test_get_standard_service(db_session, sample_redis_config, monkeypatch):
    """测试获取标准服务"""
    # 创建测试数据
    repo = StandardServiceRepository(db_session)
    created = repo.create(
        service_id=1,
        service_name="Test Service",
        component_id=1,
        service_type="redis",
        deployment_info=sample_redis_config
    )
    
    # Mock get_db_session
    from app.mcp import server as mcp_server_module
    monkeypatch.setattr(mcp_server_module, "get_db_session", lambda: db_session)
    
    # 调用MCP工具
    result = await call_tool("get_standard_service", {"id": created.id})
    assert len(result) > 0
    data = json.loads(result[0].text)
    assert "error" not in data, f"Error: {data.get('error')}"
    assert data["id"] == created.id
    assert data["service_name"] == "Test Service"
    assert data["deployment_info"] is not None


@pytest.mark.asyncio
async def test_list_standard_services(db_session, monkeypatch):
    """测试列出标准服务"""
    # 创建测试数据
    repo = StandardServiceRepository(db_session)
    for i in range(2):
        repo.create(
            service_id=i + 1,
            service_name=f"Service {i + 1}",
            component_id=1
        )
    
    # Mock get_db_session
    from app.mcp import server as mcp_server_module
    monkeypatch.setattr(mcp_server_module, "get_db_session", lambda: db_session)
    
    # 调用MCP工具
    result = await call_tool("list_standard_services", {"skip": 0, "limit": 10})
    assert len(result) > 0
    data = json.loads(result[0].text)
    assert "error" not in data, f"Error: {data.get('error')}"
    assert isinstance(data, list)
    assert len(data) >= 2


@pytest.mark.asyncio
async def test_create_deploy_service(db_session, sample_redis_config, monkeypatch):
    """测试创建部署服务"""
    # Mock get_db_session
    from app.mcp import server as mcp_server_module
    monkeypatch.setattr(mcp_server_module, "get_db_session", lambda: db_session)
    
    result = await call_tool("create_deploy_service", {
        "service_id": 1,
        "service_name": "Deploy Redis",
        "region_id": 1,
        "component_id": 1,
        "service_type": "redis",
        "deployment_info": sample_redis_config
    })
    assert len(result) > 0
    data = json.loads(result[0].text)
    assert "error" not in data, f"Error: {data.get('error')}"
    assert "id" in data
    assert data["service_name"] == "Deploy Redis"
    assert data["deployment_info"] is not None


@pytest.mark.asyncio
async def test_get_deploy_service(db_session, monkeypatch):
    """测试获取部署服务"""
    from app.repositories.service_repository import DeployServiceRepository
    repo = DeployServiceRepository(db_session)
    created = repo.create(
        service_id=1,
        service_name="Test Deploy Service",
        region_id=1,
        component_id=1
    )
    
    # Mock get_db_session
    from app.mcp import server as mcp_server_module
    monkeypatch.setattr(mcp_server_module, "get_db_session", lambda: db_session)
    
    result = await call_tool("get_deploy_service", {"id": created.id})
    assert len(result) > 0
    data = json.loads(result[0].text)
    assert "error" not in data, f"Error: {data.get('error')}"
    assert data["id"] == created.id
    assert data["service_name"] == "Test Deploy Service"


@pytest.mark.asyncio
async def test_list_deploy_services(db_session, monkeypatch):
    """测试列出部署服务"""
    from app.repositories.service_repository import DeployServiceRepository
    repo = DeployServiceRepository(db_session)
    for i in range(2):
        repo.create(
            service_id=i + 1,
            service_name=f"Deploy Service {i + 1}",
            region_id=1,
            component_id=1
        )
    
    # Mock get_db_session
    from app.mcp import server as mcp_server_module
    monkeypatch.setattr(mcp_server_module, "get_db_session", lambda: db_session)
    
    result = await call_tool("list_deploy_services", {"skip": 0, "limit": 10})
    assert len(result) > 0
    data = json.loads(result[0].text)
    assert "error" not in data, f"Error: {data.get('error')}"
    assert isinstance(data, list)
    assert len(data) >= 2


@pytest.mark.asyncio
async def test_unknown_tool():
    """测试未知工具"""
    result = await call_tool("unknown_tool", {})
    assert len(result) > 0
    data = json.loads(result[0].text)
    assert "error" in data

