# CMDB Service

CMDB (Configuration Management Database) 微服务，提供对MySQL数据库的多表CRUD操作，支持GraphQL API。

## 技术栈

- **Web框架**: FastAPI
- **GraphQL**: Strawberry
- **ORM**: SQLAlchemy 2.0+
- **数据库**: MySQL
- **验证**: Pydantic

## 项目结构

```
cmdb-service/
├── app/
│   ├── models/          # SQLAlchemy模型
│   ├── schemas/         # Pydantic Schema
│   ├── repositories/    # 数据访问层
│   ├── services/        # 业务逻辑层
│   ├── api/             # API层（GraphQL）
│   ├── core/            # 核心配置
│   └── utils/           # 工具函数
├── tests/               # 测试
├── .venv/              # 虚拟环境（使用uv创建）
├── pyproject.toml      # 项目配置（uv使用）
└── requirements.txt    # 传统依赖文件（兼容性）
```

## 快速开始

### 前置要求

- Python 3.10+
- [uv](https://github.com/astral-sh/uv) (快速安装: `pip install uv` 或 `curl -LsSf https://astral.sh/uv/install.sh | sh`)

### 1. 创建虚拟环境并安装依赖

```bash
# 创建虚拟环境（如果还没有）
uv venv .venv

# 激活虚拟环境
# Windows:
.venv\Scripts\activate
# Linux/Mac:
source .venv/bin/activate

# 安装项目依赖（包括开发依赖）
uv pip install -e ".[dev]"
```

### 2. 配置环境变量

```bash
cp .env.example .env
# 编辑 .env 文件，配置数据库连接
```

### 3. 运行服务

```bash
# 使用虚拟环境中的 uvicorn
uvicorn app.main:app --reload

# 或使用 uv 直接运行（自动使用虚拟环境）
uv run uvicorn app.main:app --reload
```

### 4. 运行测试

```bash
# 使用虚拟环境中的 pytest
pytest

# 或使用 uv 直接运行
uv run pytest
```

## API端点

- GraphQL Playground: http://localhost:8000/graphql
- GraphQL API: http://localhost:8000/graphql
- MCP Server: 通过 stdio 运行（`python -m app.mcp`）

## MCP Server

项目包含 MCP (Model Context Protocol) Server wrapper，将 CMDB 服务封装为 MCP 工具。

### 运行 MCP Server

```bash
# 使用 uv
uv run python -m app.mcp

# 或激活虚拟环境后
python -m app.mcp
```

### MCP 工具

MCP Server 提供以下工具：
- 产品管理：get_product, list_products, create_product, update_product, delete_product
- 标准服务管理：get_standard_service, list_standard_services, create_standard_service
- 部署服务管理：get_deploy_service, list_deploy_services, create_deploy_service

详细文档请参考 [app/mcp/README.md](app/mcp/README.md)

## 特性

- ✅ 多表CRUD操作
- ✅ GraphQL API（支持Union类型处理不同产品配置）
- ✅ MCP Server Wrapper（将服务封装为MCP工具）
- ✅ JSON配置字段验证（支持Redis、Nebula等不同产品类型）
- ✅ 类型安全的数据验证
- ✅ 完整的测试覆盖（包括MCP测试）
- ✅ 使用uv进行快速包管理和虚拟环境管理

## 使用uv的优势

- 🚀 **极速安装**: uv比pip快10-100倍
- 📦 **统一管理**: 使用`pyproject.toml`统一管理依赖
- 🔒 **隔离环境**: 自动管理`.venv`虚拟环境
- ⚡ **快速运行**: `uv run`自动使用虚拟环境执行命令

## 常用命令

```bash
# 创建虚拟环境
uv venv .venv

# 安装依赖
uv pip install -e ".[dev]"

# 运行服务
uv run uvicorn app.main:app --reload

# 运行测试
uv run pytest

# 添加新依赖
uv pip install package-name

# 更新依赖
uv pip install --upgrade package-name
```
- ✅ 使用uv进行快速包管理和虚拟环境管理

## 使用uv的优势

- 🚀 **极速安装**: uv比pip快10-100倍
- 📦 **统一管理**: 使用`pyproject.toml`统一管理依赖
- 🔒 **隔离环境**: 自动管理`.venv`虚拟环境
- ⚡ **快速运行**: `uv run`自动使用虚拟环境执行命令

## 常用命令

```bash
# 创建虚拟环境
uv venv .venv

# 安装依赖
uv pip install -e ".[dev]"

# 运行服务
uv run uvicorn app.main:app --reload

# 运行测试
uv run pytest

# 添加新依赖
uv pip install package-name

# 更新依赖
uv pip install --upgrade package-name
```

