# 更新日志

## [1.1.0] - 2025-01-05

### 新增

- ✨ **MCP Server Wrapper**: 添加了 MCP (Model Context Protocol) Server 封装
- 📦 **MCP 工具**: 将产品和服务管理功能封装为 MCP 工具
  - 产品管理工具：get_product, list_products, create_product, update_product, delete_product
  - 标准服务管理工具：get_standard_service, list_standard_services, create_standard_service
  - 部署服务管理工具：get_deploy_service, list_deploy_services, create_deploy_service
- ✅ **MCP 测试**: 添加了14个MCP测试用例，全部通过

### 改进

- 支持通过 MCP 协议访问 CMDB 服务
- 配置验证功能在 MCP 工具中正常工作
- 完整的错误处理

## [1.0.0] - 2025-01-05

### 重构

- ✨ **使用 uv 进行包管理**: 项目已重构为使用 `uv` 作为包管理工具
- 📦 **添加 pyproject.toml**: 使用现代 Python 项目配置标准
- 🔒 **虚拟环境管理**: 使用 `.venv` 作为虚拟环境目录
- 📝 **更新文档**: README 和 CONTRIBUTING 指南已更新

### 新增

- `pyproject.toml`: 项目配置文件，包含依赖和构建配置
- `Makefile`: 便捷的命令脚本（Linux/Mac）
- `scripts/run.ps1`: PowerShell 脚本用于运行服务
- `scripts/test.ps1`: PowerShell 脚本用于运行测试
- `CONTRIBUTING.md`: 贡献指南

### 改进

- 所有依赖现在通过 `uv` 管理
- 虚拟环境自动隔离在 `.venv` 目录
- 更快的依赖安装速度（uv 比 pip 快 10-100 倍）
- 统一的依赖管理（通过 pyproject.toml）

### 兼容性

- 保留 `requirements.txt` 以保持向后兼容
- 所有测试通过（25 个测试）

## 迁移指南

### 从传统方式迁移到 uv

1. **删除旧的虚拟环境**（如果存在）:
   ```bash
   rm -rf venv env
   ```

2. **创建新的虚拟环境**:
   ```bash
   uv venv .venv
   ```

3. **安装依赖**:
   ```bash
   uv pip install -e ".[dev]"
   ```

4. **运行命令**:
   ```bash
   # 使用 uv run（推荐）
   uv run pytest
   uv run uvicorn app.main:app --reload
   
   # 或激活虚拟环境后
   .venv\Scripts\activate  # Windows
   source .venv/bin/activate  # Linux/Mac
   pytest
   ```

