# PowerShell 脚本：运行测试
# 使用方法: .\scripts\test.ps1

# 检查虚拟环境是否存在
if (-not (Test-Path ".venv")) {
    Write-Host "创建虚拟环境..." -ForegroundColor Yellow
    uv venv .venv
}

# 检查依赖是否安装
if (-not (Test-Path ".venv\Scripts\pytest.exe")) {
    Write-Host "安装依赖..." -ForegroundColor Yellow
    uv pip install -e ".[dev]"
}

# 运行测试
Write-Host "运行测试..." -ForegroundColor Green
uv run pytest -v

