# 运行 MCP HTTP Server (SSE)
# 此脚本启动支持 Server-Sent Events 的 MCP HTTP Server

Write-Host "🚀 Starting MCP HTTP Server with SSE support..." -ForegroundColor Cyan
Write-Host ""

# 检查是否在正确的目录
if (-not (Test-Path "app\mcp\http_server.py")) {
    Write-Host "❌ Error: Please run this script from the project root directory" -ForegroundColor Red
    exit 1
}

# 检查虚拟环境
if (-not (Test-Path ".venv\Scripts\Activate.ps1")) {
    Write-Host "⚠️  Warning: Virtual environment not found. Creating one..." -ForegroundColor Yellow
    python -m venv .venv
    .\.venv\Scripts\Activate.ps1
    Write-Host "📦 Installing dependencies..." -ForegroundColor Yellow
    pip install -e .
} else {
    Write-Host "✅ Using existing virtual environment" -ForegroundColor Green
}

Write-Host ""
Write-Host "📋 Server Information:" -ForegroundColor Cyan
Write-Host "  - Server URL: http://localhost:8001" -ForegroundColor White
Write-Host "  - SSE Endpoint: http://localhost:8001/sse" -ForegroundColor White
Write-Host "  - Health Check: http://localhost:8001/health" -ForegroundColor White
Write-Host "  - Transport: Server-Sent Events (SSE)" -ForegroundColor White
Write-Host ""
Write-Host "💡 Tips:" -ForegroundColor Yellow
Write-Host "  - Use Ctrl+C to stop the server" -ForegroundColor White
Write-Host "  - Do NOT use Gunicorn (it doesn't support SSE)" -ForegroundColor White
Write-Host "  - Uvicorn fully supports SSE connections" -ForegroundColor White
Write-Host ""
Write-Host "🔧 To test with Cline, add this to your MCP settings:" -ForegroundColor Cyan
Write-Host '  {' -ForegroundColor Gray
Write-Host '    "mcpServers": {' -ForegroundColor Gray
Write-Host '      "cmdb-http": {' -ForegroundColor Gray
Write-Host '        "type": "sse",' -ForegroundColor Gray
Write-Host '        "url": "http://localhost:8001/sse"' -ForegroundColor Gray
Write-Host '      }' -ForegroundColor Gray
Write-Host '    }' -ForegroundColor Gray
Write-Host '  }' -ForegroundColor Gray
Write-Host ""
Write-Host "Starting server..." -ForegroundColor Green
Write-Host "----------------------------------------" -ForegroundColor Gray

# 运行服务器
try {
    # 方法 1: 直接运行 http_main.py
    python -m app.mcp.http_main
    
    # 方法 2: 使用 uvicorn 命令（备选）
    # uvicorn app.mcp.http_server:http_app --host 0.0.0.0 --port 8001 --timeout-keep-alive 75
}
catch {
    Write-Host ""
    Write-Host "❌ Server stopped with error: $_" -ForegroundColor Red
    exit 1
}
