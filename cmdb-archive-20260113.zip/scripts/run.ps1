# PowerShell 脚本：运行服务
# 使用方法: .\scripts\run.ps1

# 检查虚拟环境是否存在
if (-not (Test-Path ".venv")) {
    Write-Host "创建虚拟环境..." -ForegroundColor Yellow
    uv venv .venv
}

# 检查依赖是否安装
if (-not (Test-Path ".venv\Scripts\uvicorn.exe")) {
    Write-Host "安装依赖..." -ForegroundColor Yellow
    uv pip install -e ".[dev]"
}

# 运行服务
Write-Host "启动服务..." -ForegroundColor Green
uv run uvicorn app.main:app --reload

