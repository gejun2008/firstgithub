# 贡献指南

## 开发环境设置

### 使用 uv (推荐)

```bash
# 1. 安装 uv (如果还没有)
pip install uv
# 或
curl -LsSf https://astral.sh/uv/install.sh | sh

# 2. 创建虚拟环境
uv venv .venv

# 3. 激活虚拟环境
# Windows:
.venv\Scripts\activate
# Linux/Mac:
source .venv/bin/activate

# 4. 安装开发依赖
uv pip install -e ".[dev]"
```

### 使用传统方式

```bash
# 1. 创建虚拟环境
python -m venv .venv

# 2. 激活虚拟环境
# Windows:
.venv\Scripts\activate
# Linux/Mac:
source .venv/bin/activate

# 3. 安装依赖
pip install -r requirements.txt
pip install -e .
```

## 运行测试

```bash
# 使用 uv
uv run pytest

# 或激活虚拟环境后
pytest
```

## 代码规范

- 使用 Python 3.10+ 特性
- 遵循 PEP 8 代码风格
- 使用类型提示
- 编写单元测试

## 提交代码

1. 确保所有测试通过
2. 确保代码符合规范
3. 提交清晰的 commit message

