# MCP 传输方式对比：stdio vs Streamable HTTP

## 概述

MCP (Model Context Protocol) 支持两种主要的传输方式：
1. **stdio** (标准输入输出)
2. **streamable-http** (HTTP with Server-Sent Events)

## 详细对比

### stdio 传输

#### 工作原理
- 通过标准输入（stdin）接收请求
- 通过标准输出（stdout）发送响应
- 客户端启动服务器进程，通过管道通信

#### 优点
- ✅ **简单直接**：无需网络配置
- ✅ **低延迟**：进程间直接通信
- ✅ **安全性高**：本地进程通信，无网络暴露
- ✅ **资源占用少**：无需 HTTP 服务器开销
- ✅ **适合本地开发**：与 Claude Desktop 等本地客户端集成

#### 缺点
- ❌ **单客户端**：一个进程只能服务一个客户端
- ❌ **无网络访问**：无法通过网络访问
- ❌ **生命周期绑定**：服务器进程与客户端进程绑定
- ❌ **不适合生产环境**：难以扩展和监控

#### 适用场景
- Claude Desktop 等本地客户端
- 命令行工具集成
- 本地开发和测试
- 单用户场景

### Streamable HTTP 传输

#### 工作原理
- 服务器作为独立的 HTTP 服务运行
- 使用 HTTP POST 发送请求
- 使用 Server-Sent Events (SSE) 流式返回响应
- 支持多客户端并发连接

#### 优点
- ✅ **多客户端支持**：可以同时服务多个客户端
- ✅ **网络访问**：可以通过网络访问，支持分布式部署
- ✅ **独立运行**：服务器可以独立运行，不依赖客户端生命周期
- ✅ **生产就绪**：适合生产环境部署
- ✅ **可扩展性**：可以负载均衡、横向扩展
- ✅ **监控和日志**：更容易监控和记录日志
- ✅ **符合 MCP Hub 标准**：大多数 MCP Hub 使用此方式

#### 缺点
- ❌ **配置复杂**：需要配置 HTTP 服务器、端口等
- ❌ **网络延迟**：相比 stdio 有网络延迟
- ❌ **需要身份验证**：需要实现安全机制
- ❌ **资源占用**：需要 HTTP 服务器资源

#### 适用场景
- MCP Hub 等云服务
- Web 应用集成
- 多客户端场景
- 生产环境部署
- 分布式系统

## 技术实现对比

### stdio 实现

```python
from mcp.server.stdio import stdio_server

async def run_mcp_server():
    async with stdio_server() as (read_stream, write_stream):
        await mcp_server.run(read_stream, write_stream, ...)
```

**特点：**
- 使用 `stdio_server()` 创建传输层
- 通过管道（pipe）通信
- 客户端通过 `command` 和 `args` 启动服务器

### HTTP SSE 实现

```python
from mcp.server.sse import SseServerTransport
from fastapi import FastAPI
from sse_starlette.sse import EventSourceResponse

app = FastAPI()

@app.post("/messages")
async def handle_messages(request: Request):
    transport = SseServerTransport("/messages", "/messages")
    async with transport.connect_sse(request) as streams:
        await mcp_server.run(streams[0], streams[1], ...)
```

**特点：**
- 使用 HTTP POST 接收请求
- 使用 SSE 流式返回响应
- 支持多个并发连接

## 配置示例

### stdio 配置（Claude Desktop）

```json
{
  "mcpServers": {
    "cmdb-service": {
      "command": "python",
      "args": ["-m", "app.mcp"],
      "env": {
        "DATABASE_URL": "mysql+pymysql://..."
      }
    }
  }
}
```

### HTTP SSE 配置（MCP Hub）

```json
{
  "mcpServers": {
    "cmdb-service": {
      "url": "https://cmdb-service.example.com/mcp",
      "headers": {
        "Authorization": "Bearer token"
      }
    }
  }
}
```

## 性能对比

| 特性 | stdio | HTTP SSE |
|------|-------|----------|
| 延迟 | 极低（<1ms） | 低（10-50ms） |
| 吞吐量 | 高（单客户端） | 高（多客户端） |
| 并发连接 | 1 | 多 |
| 资源占用 | 低 | 中等 |
| 网络要求 | 无 | 需要 |

## 选择建议

### 使用 stdio 当：
- ✅ 本地开发环境
- ✅ 与 Claude Desktop 集成
- ✅ 单用户场景
- ✅ 需要最低延迟
- ✅ 简单快速集成

### 使用 HTTP SSE 当：
- ✅ 需要部署到 MCP Hub
- ✅ 多客户端访问
- ✅ 生产环境
- ✅ 需要网络访问
- ✅ 需要可扩展性

## 迁移路径

项目同时支持两种传输方式：
- **stdio**: `python -m app.mcp` (默认)
- **HTTP SSE**: `python -m app.mcp.http` (可选)

可以根据使用场景选择合适的传输方式。

