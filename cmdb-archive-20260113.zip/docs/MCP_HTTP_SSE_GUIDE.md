# MCP HTTP Server with SSE Guide

本指南介绍如何运行和测试支持 Server-Sent Events (SSE) 的 MCP HTTP Server。

## 什么是 Streamable HTTP (SSE)?

MCP 支持多种传输协议：
- **stdio**: 标准输入输出（用于 CLI 工具）
- **SSE (Server-Sent Events)**: HTTP 流式传输（用于 Web 应用）

SSE 是一种基于 HTTP 的单向流式通信协议，服务器可以持续向客户端推送数据。MCP 在 SSE 基础上实现了双向通信：
- 服务器通过 SSE 向客户端推送消息
- 客户端通过 POST 请求向服务器发送消息

## 运行要求

### ✅ 支持的服务器
- **Uvicorn** - 完全支持 SSE，推荐使用
- **Hypercorn** - 支持 SSE
- **Daphne** - 支持 SSE

### ❌ 不支持的服务器
- **Gunicorn** - 不支持长连接和 SSE
- **uWSGI** - 不支持 SSE

## 运行服务器

### 方法 1: 直接运行（推荐）

```bash
# 使用 Python
python -m app.mcp.http_main

# 或使用 uv（如果已安装）
uv run python -m app.mcp.http_main
```

### 方法 2: 使用 Uvicorn 命令行

```bash
# 基本运行
uvicorn app.mcp.http_server:http_app --host 0.0.0.0 --port 8001

# 开发模式（自动重载）
uvicorn app.mcp.http_server:http_app --host 0.0.0.0 --port 8001 --reload

# 生产模式（带优化配置）
uvicorn app.mcp.http_server:http_app \
  --host 0.0.0.0 \
  --port 8001 \
  --timeout-keep-alive 75 \
  --timeout-graceful-shutdown 10 \
  --log-level info
```

### 方法 3: 使用 PowerShell 脚本

```powershell
# Windows
.\scripts\run_http_server.ps1
```

## 测试服务器

### 1. 检查服务器状态

```bash
# 检查健康状态
curl http://localhost:8001/health

# 查看服务器信息
curl http://localhost:8001/
```

预期响应：
```json
{
  "name": "CMDB Service - MCP HTTP Server",
  "version": "1.0.0",
  "transport": "sse",
  "protocol": "streamable-http",
  "endpoint": "/sse",
  "methods": ["POST"],
  "description": "MCP Server with Server-Sent Events (SSE) transport"
}
```

### 2. 使用 Cline 测试

Cline 是一个支持 MCP 的 VSCode 扩展。配置方法：

1. 在 VSCode 中安装 Cline 扩展
2. 打开 Cline 设置
3. 添加 MCP 服务器配置：

```json
{
  "mcpServers": {
    "cmdb-http": {
      "type": "sse",
      "url": "http://localhost:8001/sse",
      "timeout": 60000
    }
  }
}
```

### 3. 使用 Python 测试客户端

```python
import httpx
import asyncio
import json

async def test_mcp_sse():
    """测试 MCP SSE 连接"""
    url = "http://localhost:8001/sse"
    
    # 初始化请求
    init_message = {
        "jsonrpc": "2.0",
        "method": "initialize",
        "params": {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {
                "name": "test-client",
                "version": "1.0.0"
            }
        },
        "id": 1
    }
    
    async with httpx.AsyncClient(timeout=60.0) as client:
        # 发送初始化请求
        response = await client.post(
            url,
            json=init_message,
            headers={
                "Content-Type": "application/json",
                "Accept": "text/event-stream"
            }
        )
        
        print(f"Status: {response.status_code}")
        print(f"Headers: {response.headers}")
        print(f"Response: {response.text}")

# 运行测试
asyncio.run(test_mcp_sse())
```

### 4. 使用 curl 测试

```bash
# 发送初始化请求
curl -X POST http://localhost:8001/sse \
  -H "Content-Type: application/json" \
  -H "Accept: text/event-stream" \
  -d '{
    "jsonrpc": "2.0",
    "method": "initialize",
    "params": {
      "protocolVersion": "2024-11-05",
      "capabilities": {},
      "clientInfo": {
        "name": "test-client",
        "version": "1.0.0"
      }
    },
    "id": 1
  }'
```

## 常见问题

### Q: 为什么不能使用 Gunicorn?
A: Gunicorn 是一个传统的 WSGI 服务器，不支持长连接和流式传输。SSE 需要保持 HTTP 连接打开以持续推送数据，Gunicorn 会在响应完成后立即关闭连接。

### Q: 可以使用多进程吗?
A: 对于 SSE，建议使用单进程多协程模式（Uvicorn 默认）。如果需要扩展，可以：
- 使用反向代理（Nginx/Traefik）+ 多个 Uvicorn 进程
- 使用容器编排（Docker Swarm/Kubernetes）

### Q: SSE 连接超时怎么办?
A: 已配置 `timeout_keep_alive=75` 秒。客户端应定期发送心跳或重连。

### Q: 如何调试 SSE 连接?
A: 
1. 检查浏览器开发者工具的 Network 标签
2. 查看服务器日志（已添加详细日志记录）
3. 使用 `--log-level debug` 运行 Uvicorn

## 生产环境部署

### 1. 使用 Systemd (Linux)

创建 `/etc/systemd/system/cmdb-mcp-http.service`:

```ini
[Unit]
Description=CMDB MCP HTTP Server
After=network.target

[Service]
Type=simple
User=cmdb
WorkingDirectory=/opt/cmdb
Environment="DATABASE_URL=mysql+pymysql://user:pass@localhost/cmdb"
ExecStart=/opt/cmdb/venv/bin/uvicorn app.mcp.http_server:http_app \
  --host 0.0.0.0 \
  --port 8001 \
  --timeout-keep-alive 75
Restart=always

[Install]
WantedBy=multi-user.target
```

启动服务：
```bash
sudo systemctl enable cmdb-mcp-http
sudo systemctl start cmdb-mcp-http
```

### 2. 使用 Docker

```dockerfile
FROM python:3.10-slim

WORKDIR /app
COPY . .
RUN pip install -e .

EXPOSE 8001

CMD ["uvicorn", "app.mcp.http_server:http_app", \
     "--host", "0.0.0.0", \
     "--port", "8001", \
     "--timeout-keep-alive", "75"]
```

### 3. 使用 Nginx 反向代理

```nginx
upstream cmdb_mcp {
    server 127.0.0.1:8001;
}

server {
    listen 80;
    server_name mcp.example.com;

    location / {
        proxy_pass http://cmdb_mcp;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        
        # SSE 需要禁用缓冲
        proxy_buffering off;
        proxy_cache off;
        
        # 超时配置
        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
    }
}
```

## 性能优化

### Uvicorn 配置选项

```bash
uvicorn app.mcp.http_server:http_app \
  --host 0.0.0.0 \
  --port 8001 \
  --workers 1 \  # SSE 建议单进程
  --loop asyncio \  # 使用 asyncio 事件循环
  --timeout-keep-alive 75 \
  --limit-concurrency 1000 \
  --limit-max-requests 0  # 0 = 无限制
```

## 监控和日志

### 日志配置

```python
# 在 app/core/config.py 中设置
LOG_LEVEL = "INFO"  # DEBUG, INFO, WARNING, ERROR
```

### 监控指标

建议监控：
- 活跃 SSE 连接数
- 请求/响应延迟
- 错误率
- 内存使用

## 参考资料

- [MCP Specification](https://spec.modelcontextprotocol.io/)
- [Uvicorn Documentation](https://www.uvicorn.org/)
- [Server-Sent Events (SSE) Specification](https://html.spec.whatwg.org/multipage/server-sent-events.html)
- [FastAPI WebSockets & SSE](https://fastapi.tiangolo.com/advanced/websockets/)
