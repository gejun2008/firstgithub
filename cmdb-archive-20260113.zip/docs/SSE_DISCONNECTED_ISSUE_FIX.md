# SSE Stream Disconnected 问题分析与解决

## 问题现象

在 Cline 中配置 MCP Server（Streamable HTTP）后，出现错误：
```
SSE stream disconnected: AbortError: This operation was aborted
```

## 根本原因

### 1. SSE 连接的特性

**SSE (Server-Sent Events) 是长连接协议：**
- 客户端发起连接后，**服务器必须保持连接打开**
- 服务器通过这个打开的连接持续发送事件
- 连接应该保持打开直到客户端主动断开或发生错误

### 2. 原始实现的问题

**错误的代码：**
```python
@http_app.post("/sse")
async def sse_endpoint(request: Request) -> Response:
    async with transport.connect_sse(...) as streams:
        await mcp_server.run(
            streams[0],
            streams[1],
            mcp_server.create_initialization_options(),
        )
    return Response()  # ❌ 问题在这里！
```

**问题分析：**
1. `mcp_server.run()` 启动 MCP 服务器会话
2. 初始化完成后，`mcp_server.run()` 返回
3. `async with` 块退出
4. `return Response()` 执行，**立即关闭 HTTP 连接**
5. 客户端（Cline）检测到 SSE 流断开
6. 报错：`SSE stream disconnected: AbortError`

### 3. MCP Streamable HTTP 的工作原理

**正确的通信流程：**

```
客户端 (Cline)                    服务器
     |                                |
     |---POST /sse (initialize)------>|
     |                                |
     |<--SSE: 200 OK, keep alive------|
     |                                |
     |<--SSE: event (init result)-----|
     |                                |
     |---POST /sse (tools/list)------>|
     |                                |
     |<--SSE: event (tools list)------|
     |                                |
     |---POST /sse (tools/call)------>|
     |                                |
     |<--SSE: event (call result)-----|
     |                                |
     |        ... 持续保持 ...         |
     |                                |
     |---客户端断开----------------->|
     |                                |
```

**关键点：**
- 第一个 POST 请求建立 SSE 连接
- **连接一直保持打开**
- 后续的 POST 请求在同一个会话中处理
- 响应通过 SSE 流返回
- `mcp_server.run()` **应该阻塞**直到客户端断开

## 解决方案

### 修复后的代码

```python
@http_app.post("/sse")
@http_app.get("/sse")  # 有些客户端可能用 GET
async def sse_endpoint(request: Request) -> Response:
    """
    MCP Streamable HTTP endpoint with Server-Sent Events (SSE)
    
    关键：此函数不应该快速返回，连接应该保持打开
    """
    logger.info(f"SSE endpoint called with method: {request.method}")
    
    try:
        # transport.connect_sse() 返回一个上下文管理器
        # 它会处理 SSE 响应的发送，包括保持连接打开
        async with transport.connect_sse(
            request.scope,
            request.receive,
            request._send,
        ) as streams:
            logger.info("SSE connection established, starting MCP server session...")
            
            # ✅ mcp_server.run() 会阻塞直到连接关闭
            # 这是正确的行为！不要试图让它快速返回
            await mcp_server.run(
                streams[0],
                streams[1],
                mcp_server.create_initialization_options(),
            )
            
            logger.info("MCP server session ended normally")
    except Exception as e:
        logger.error(f"Error in SSE endpoint: {e}", exc_info=True)
        raise
    
    # 只有在连接正常关闭后才会到达这里
    return Response(status_code=200)
```

### 关键改进

1. **支持 GET 和 POST**
   - 添加了 `@http_app.get("/sse")` 装饰器
   - 有些 MCP 客户端可能使用 GET 建立初始连接

2. **正确处理连接生命周期**
   - `mcp_server.run()` **应该阻塞**
   - 连接由 `transport.connect_sse()` 内部管理
   - 不要过早返回 `Response()`

3. **更好的日志记录**
   - 记录请求方法（GET/POST）
   - 记录连接建立和结束

## MCP SDK 的 SseServerTransport 工作原理

### transport.connect_sse() 的内部机制

```python
async with transport.connect_sse(scope, receive, send) as streams:
    # streams[0]: ReadStream - 从客户端接收消息
    # streams[1]: WriteStream - 向客户端发送消息
    
    await mcp_server.run(streams[0], streams[1], options)
    
    # run() 会：
    # 1. 处理初始化握手
    # 2. 监听客户端的 JSON-RPC 请求
    # 3. 通过 WriteStream 发送响应（作为 SSE 事件）
    # 4. 保持循环运行直到连接断开
```

**关键理解：**
- `transport.connect_sse()` 已经设置了 SSE 响应头
- `mcp_server.run()` 负责处理所有 MCP 协议交互
- **连接由 MCP SDK 内部管理，不需要手动处理**

## 验证修复

### 1. 启动服务器

```bash
python -m app.mcp.http_main
```

**预期输出：**
```
🚀 Starting MCP HTTP Server with SSE support...
📍 Server will be available at: http://0.0.0.0:8001
🔗 SSE endpoint: http://0.0.0.0:8001/sse
INFO:     Started server process
INFO:     Uvicorn running on http://0.0.0.0:8001
```

### 2. 配置 Cline

```json
{
  "mcpServers": {
    "cmdb-http": {
      "type": "sse",
      "url": "http://localhost:8001/sse"
    }
  }
}
```

### 3. 观察服务器日志

**成功连接的日志：**
```
INFO:app.mcp.http_server:SSE endpoint called with method: POST
INFO:app.mcp.http_server:SSE connection established, starting MCP server session...
```

**不应该立即看到：**
```
INFO:app.mcp.http_server:MCP server session ended normally  # 不应该立即出现
```

只有当 Cline 断开连接时才会看到这条日志。

### 4. 在 Cline 中测试

**应该能够：**
- ✅ 看到 CMDB 服务器连接成功
- ✅ 列出所有工具（get_product, list_products, 等）
- ✅ 调用工具并获得结果
- ✅ 没有 "SSE stream disconnected" 错误

## 常见问题

### Q1: 为什么需要同时支持 GET 和 POST？

**A:** 不同的 MCP 客户端实现可能使用不同的方法：
- **POST**: 大多数客户端使用 POST 建立连接并发送初始化消息
- **GET**: 有些客户端可能先用 GET 建立 SSE 连接，然后用 POST 发送消息

### Q2: mcp_server.run() 会永远阻塞吗？

**A:** 不会。它会阻塞直到：
- 客户端关闭连接
- 发生错误
- 服务器主动关闭

这是正常的行为，这就是 SSE 长连接应该工作的方式。

### Q3: 如何处理多个客户端？

**A:** FastAPI + Uvicorn 会为每个请求创建一个新的协程：
- 每个客户端连接对应一个 `sse_endpoint()` 调用
- 每个调用在独立的协程中运行
- `mcp_server.run()` 在各自的协程中阻塞
- Uvicorn 自动处理并发

### Q4: 连接会超时吗？

**A:** 配置了 `timeout_keep_alive=75` 秒：
- 如果 75 秒内没有活动，连接可能超时
- MCP 客户端通常会发送心跳保持连接
- 可以根据需要调整超时时间

### Q5: 如何调试 SSE 连接？

**方法 1：浏览器开发者工具**
```javascript
// 在浏览器控制台
const eventSource = new EventSource('http://localhost:8001/sse');
eventSource.onmessage = (e) => console.log('Message:', e.data);
eventSource.onerror = (e) => console.error('Error:', e);
```

**方法 2：curl 测试**
```bash
curl -N -H "Accept: text/event-stream" http://localhost:8001/sse
```

**方法 3：查看服务器日志**
```bash
# 设置 DEBUG 级别
uvicorn app.mcp.http_server:http_app --log-level debug
```

## 技术细节：Streamable HTTP vs 传统 HTTP

### 传统 HTTP 请求-响应

```
客户端                  服务器
  |                       |
  |----请求--------------->|
  |                       |
  |<---响应（立即）--------|
  |                       |
  连接关闭
```

### Streamable HTTP (SSE)

```
客户端                  服务器
  |                       |
  |----请求--------------->|
  |                       |
  |<---响应头（SSE）--------|
  |                       |
  |<===保持连接打开========|
  |                       |
  |<---event: data--------|
  |                       |
  |<---event: data--------|
  |                       |
  |    ... 持续 ...       |
  |                       |
  客户端主动断开
```

## 总结

### 问题本质

**原始代码的错误：**
- ❌ 过早关闭连接
- ❌ 没有保持 SSE 流打开
- ❌ 导致客户端看到 AbortError

### 解决方案

**修复后的代码：**
- ✅ 让 `mcp_server.run()` 正常阻塞
- ✅ 由 MCP SDK 管理连接生命周期
- ✅ 连接保持打开直到客户端断开

### 验证步骤

1. 重启服务器
2. 在 Cline 中重新连接
3. 观察服务器日志不应该立即结束
4. 测试工具调用
5. 确认没有断开错误

---

**重要提醒：** SSE 是**长连接**，不是传统的请求-响应模式。服务器端函数**应该阻塞**直到客户端断开，这是正常的、期望的行为！
