-- MySQL dump 10.13  Distrib 5.7.30, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: cmdb
-- ------------------------------------------------------
-- Server version	5.7.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `cmdb`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `cmdb` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `cmdb`;

--
-- Table structure for table `deploy_Component`
--

DROP TABLE IF EXISTS `deploy_component`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deploy_component` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `component_id` int(11) NOT NULL COMMENT '组件ID',
  `component_name` varchar(100) NOT NULL COMMENT '组件名称',
  `region_id` tinyint(5) NOT NULL COMMENT '区域ID',
  `action` tinyint DEFAULT NULL COMMENT '操作类型',
  `product_id` int(11) NOT NULL COMMENT '产品ID',
  `parent_component_id` varchar(50) DEFAULT NULL COMMENT '父组件ID',
  `component_alias` varchar(100) DEFAULT NULL COMMENT '组件别名',
  `component_version` varchar(50) DEFAULT NULL COMMENT '组件版本',
  `component_desc` text COMMENT '组件描述',
  `component_type` varchar(50) DEFAULT NULL COMMENT '组件类型',
  `deployment_dependencies` JSON COMMENT '部署依赖',
  `call_dependencies` text COMMENT '调用依赖',
  `deployment_information` JSON COMMENT '部署信息',
  `deploy_status` varchar(20) DEFAULT 'pending' COMMENT '部署状态',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_component_id` (`component_ID`),
  KEY `idx_region_id` (`region_ID`),
  KEY `idx_product_id` (`product_ID`),
  KEY `idx_parent_component_id` (`parent_component_ID`),
  KEY `idx_component_type` (`component_type`),
  CONSTRAINT `deploy_Component_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE,
  CONSTRAINT `deploy_Component_ibfk_2` FOREIGN KEY (`region_id`) REFERENCES `regions` (`region_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='部署组件表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deploy_Component`
--

LOCK TABLES `deploy_Component` WRITE;
/*!40000 ALTER TABLE `deploy_Component` DISABLE KEYS */;
/*!40000 ALTER TABLE `deploy_Component` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deploy_products`
--

DROP TABLE IF EXISTS `deploy_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deploy_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `deploy_id` varchar(50) NOT NULL COMMENT '部署ID',
  `region_name` varchar(100) NOT NULL COMMENT '区域名称',
  `region_id` tinyint(5) NOT NULL COMMENT '区域ID',
  `product_id` varchar(50) NOT NULL COMMENT '产品ID',
  `deploy_status` varchar(20) DEFAULT 'pending' COMMENT '部署状态',
  `deploy_time` timestamp NULL DEFAULT NULL COMMENT '部署时间',
  `deploy_operator` varchar(100) DEFAULT NULL COMMENT '部署操作人',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `deploy_id` (`deploy_id`),
  KEY `idx_region_name` (`region_name`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_deploy_status` (`deploy_status`),
  CONSTRAINT `deploy_products_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE,
  CONSTRAINT `deploy_products_ibfk_2` FOREIGN KEY (`region_id`) REFERENCES `regions` (`region_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='产品部署表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deploy_products`
--

LOCK TABLES `deploy_products` WRITE;
/*!40000 ALTER TABLE `deploy_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `deploy_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deploy_services`
--

DROP TABLE IF EXISTS `deploy_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deploy_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `service_id` int(11) NOT NULL COMMENT '服务ID',
  `service_name` varchar(100) NOT NULL COMMENT '服务名称',
  `region_id` int(11) NOT NULL COMMENT '区域ID',
  `action` tinyint(5) DEFAULT NULL COMMENT '操作类型',
  `component_id` int(11) NOT NULL COMMENT '组件ID',
  `service_desc` text COMMENT '服务描述',
  `service_version` varchar(50) DEFAULT NULL COMMENT '服务版本',
  `service_type` varchar(50) DEFAULT NULL COMMENT '服务类型',
  `deployment_type` varchar(50) DEFAULT NULL COMMENT '部署类型',
  `deployment_info` JSON COMMENT '部署信息',
  `cpu_request_value` decimal(10,2) DEFAULT NULL COMMENT 'CPU请求值',
  `cpu_limit_value` decimal(10,2) DEFAULT NULL COMMENT 'CPU限制值',
  `memory_request_value` int(11) DEFAULT NULL COMMENT '内存请求值(MB)',
  `memory_limit_value` int(11) DEFAULT NULL COMMENT '内存限制值(MB)',
  `owner` varchar(100) DEFAULT NULL COMMENT '负责人',
  `self_inspection_logic` text COMMENT '自检逻辑',
  `deploy_status` varchar(20) DEFAULT 'pending' COMMENT '部署状态',
  `health_status` varchar(20) DEFAULT 'unknown' COMMENT '健康状态',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_service_id` (`service_id`),
  KEY `idx_service_name` (`service_name`),
  KEY `idx_region_id` (`region_id`),
  KEY `idx_component_id` (`component_id`),
  KEY `idx_service_type` (`service_type`),
  KEY `idx_owner` (`owner`),
  KEY `idx_deploy_status` (`deploy_status`),
  CONSTRAINT `deploy_products_ibfk_1` FOREIGN KEY (`region_id`) REFERENCES `regions` (`region_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='部署服务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deploy_services`
--

LOCK TABLES `deploy_services` WRITE;
/*!40000 ALTER TABLE `deploy_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `deploy_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `product_id` tinyint(5) NOT NULL COMMENT '产品ID',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `product_version` varchar(50) DEFAULT NULL COMMENT '产品版本',
  `product_desc` text COMMENT '产品描述',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`),
  KEY `idx_product_name` (`product_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='产品信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regions`
--

DROP TABLE IF EXISTS `regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regions` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `region_id` tinyint(5) NOT NULL COMMENT '区域ID',
  `region_name` varchar(100) NOT NULL COMMENT '区域名称',
  `region_desc` text COMMENT '区域描述',
  `pm_owner` varchar(100) DEFAULT NULL COMMENT '产品负责人',
  `gtm_owner` varchar(100) DEFAULT NULL COMMENT 'GTM负责人',
  `op_owner` varchar(100) DEFAULT NULL COMMENT '运维负责人',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `region_id` (`region_id`),
  KEY `idx_region_name` (`region_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='区域信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regions`
--

LOCK TABLES `regions` WRITE;
/*!40000 ALTER TABLE `regions` DISABLE KEYS */;
/*!40000 ALTER TABLE `regions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `standard_Component`
--

DROP TABLE IF EXISTS `standard_component`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `standard_component` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `component_id` int(11) NOT NULL COMMENT '组件ID',
  `component_name` varchar(100) NOT NULL COMMENT '组件名称',
  `product_id` tinyint(5) NOT NULL COMMENT '产品ID',
  `parent_component_id` int(11) DEFAULT NULL COMMENT '父组件ID',
  `component_alias` varchar(100) DEFAULT NULL COMMENT '组件别名',
  `component_version` varchar(50) DEFAULT NULL COMMENT '组件版本',
  `component_desc` text COMMENT '组件描述',
  `component_type` varchar(50) DEFAULT NULL COMMENT '组件类型',
  `deployment_dependencies` JSON COMMENT '部署依赖',
  `call_dependencies` text COMMENT '调用依赖',
  `deployment_information` JSON COMMENT '部署信息',
  `is_active` tinyint(1) DEFAULT '1' COMMENT '是否激活',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `component_id` (`component_id`),
  KEY `idx_component_name` (`component_name`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_parent_component_id` (`parent_component_id`),
  KEY `idx_component_type` (`component_type`),
  CONSTRAINT `standard_Component_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='标准组件表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `standard_Component`
--

LOCK TABLES `standard_Component` WRITE;
/*!40000 ALTER TABLE `standard_Component` DISABLE KEYS */;
/*!40000 ALTER TABLE `standard_Component` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `standard_services`
--

DROP TABLE IF EXISTS `standard_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `standard_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `service_id` int(11) NOT NULL COMMENT '服务ID',
  `service_name` varchar(100) NOT NULL COMMENT '服务名称',
  `component_id` int(11) NOT NULL COMMENT '组件ID',
  `service_desc` text COMMENT '服务描述',
  `service_version` varchar(50) DEFAULT NULL COMMENT '服务版本',
  `service_type` varchar(50) DEFAULT NULL COMMENT '服务类型',
  `deployment_type` varchar(50) DEFAULT NULL COMMENT '部署类型',
  `deployment_info` JSON COMMENT '部署信息',
  `cpu_request_value` decimal(10,2) DEFAULT NULL COMMENT 'CPU请求值',
  `cpu_limit_value` decimal(10,2) DEFAULT NULL COMMENT 'CPU限制值',
  `memory_request_value` int(11) DEFAULT NULL COMMENT '内存请求值(MB)',
  `memory_limit_value` int(11) DEFAULT NULL COMMENT '内存限制值(MB)',
  `owner` varchar(100) DEFAULT NULL COMMENT '负责人',
  `self_inspection_logic` text COMMENT '自检逻辑',
  `is_active` tinyint(1) DEFAULT '1' COMMENT '是否激活',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `service_id` (`service_id`),
  KEY `idx_service_name` (`service_name`),
  KEY `idx_component_id` (`component_id`),
  KEY `idx_service_type` (`service_type`),
  KEY `idx_owner` (`owner`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='标准服务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `standard_services`
--

LOCK TABLES `standard_services` WRITE;
/*!40000 ALTER TABLE `standard_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `standard_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_service_monitoring_index`
--

DROP TABLE IF EXISTS `t_service_monitoring_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_service_monitoring_index` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `product_name` varchar(100) NOT NULL COMMENT '产品名称',
  `service_name` varchar(100) NOT NULL COMMENT '服务名称',
  `monitoring_index_name` varchar(100) NOT NULL COMMENT '监控指标名称',
  `monitoring_index_desc` text COMMENT '监控指标描述',
  `monitoring_index_threshold` varchar(200) DEFAULT NULL COMMENT '监控指标阈值',
  `monitoring_unit` varchar(50) DEFAULT NULL COMMENT '监控单位',
  `alert_level` varchar(20) DEFAULT NULL COMMENT '告警级别',
  `is_enabled` tinyint(1) DEFAULT '1' COMMENT '是否启用',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_product_service_index` (`product_name`,`service_name`,`monitoring_index_name`),
  KEY `idx_product_name` (`product_name`),
  KEY `idx_service_name` (`service_name`),
  KEY `idx_monitoring_index_name` (`monitoring_index_name`),
  KEY `idx_alert_level` (`alert_level`),
  KEY `idx_is_enabled` (`is_enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='服务监控指标表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_service_monitoring_index`
--

LOCK TABLES `t_service_monitoring_index` WRITE;
/*!40000 ALTER TABLE `t_service_monitoring_index` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_service_monitoring_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `virtual_machines`
--

DROP TABLE IF EXISTS `virtual_machines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `virtual_machines` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `vm_name` varchar(100) NOT NULL COMMENT '虚拟机名称',
  `service_id` varchar(100) DEFAULT NULL COMMENT '服务ID',
--  `vm_product` varchar(100) DEFAULT NULL COMMENT '虚拟机产品',
--  `vm_application` varchar(200) DEFAULT NULL COMMENT '虚拟机应用',
  `region_id` tinyint(5) DEFAULT NULL COMMENT '区域ID',
  `vm_ip_address` varchar(50) DEFAULT NULL COMMENT '虚拟机IP地址',
  `vm_status` varchar(20) DEFAULT NULL COMMENT '虚拟机状态',
  `vm_server_name` varchar(100) DEFAULT NULL COMMENT '虚拟机服务器名称',
  `vm_type` varchar(50) DEFAULT NULL COMMENT '虚拟机类型',
  `vm_specification` varchar(100) DEFAULT NULL COMMENT '虚拟机规格',
  `vm_cpu_cores` int(11) DEFAULT NULL COMMENT 'CPU核心数',
  `vm_memory` int(11) DEFAULT NULL COMMENT '内存大小(GB)',
  `vm_os` varchar(50) DEFAULT NULL COMMENT '操作系统',
  `vm_os_edition` varchar(50) DEFAULT NULL COMMENT '操作系统版本',
  `virtualization_platform` varchar(50) DEFAULT NULL COMMENT '虚拟化平台',
  `vm_security_zone` varchar(50) DEFAULT NULL COMMENT '安全区域',
  `system_disk_type` varchar(50) DEFAULT NULL COMMENT '系统盘类型',
  `system_disk_size` int(11) DEFAULT NULL COMMENT '系统盘大小(GiB)',
  `data_disk` JSON  COMMENT '数据盘',
  `vpc_name` varchar(100) DEFAULT NULL COMMENT 'VPC名称',
  `subnet_name` varchar(100) DEFAULT NULL COMMENT '子网名称',
  `vm_owner` varchar(100) DEFAULT NULL COMMENT '虚拟机负责人',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_vm_name` (`vm_name`),
  KEY `idx_region_id` (`region_id`),
  KEY `idx_service_id` (`service_id`),
  KEY `idx_vm_status` (`vm_status`),
  KEY `idx_vm_owner` (`vm_owner`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='虚拟机信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `virtual_machines`
--

LOCK TABLES `virtual_machines` WRITE;
/*!40000 ALTER TABLE `virtual_machines` DISABLE KEYS */;
/*!40000 ALTER TABLE `virtual_machines` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-05  6:18:52
