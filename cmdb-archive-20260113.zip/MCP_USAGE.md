# MCP Server 使用指南

## 概述

CMDB Service 已封装为 MCP (Model Context Protocol) Server，支持两种传输模式：
- **stdio**: 标准输入输出（用于 CLI 工具，如 Claude Desktop）
- **SSE (Server-Sent Events)**: HTTP 流式传输（用于 Web 应用，如 Cline）

## 安装和运行

### 1. 确保依赖已安装

```bash
uv pip install -e ".[dev]"
```

### 2. 运行 MCP Server

#### 方式 A: stdio 模式（用于 Claude Desktop）

MCP Server 通过 stdio 与客户端通信：

```bash
# 使用 uv
uv run python -m app.mcp

# 或激活虚拟环境后
python -m app.mcp
```

#### 方式 B: HTTP/SSE 模式（用于 Cline 等 Web 客户端）

```bash
# 方法 1: 使用 Python 脚本
python -m app.mcp.http_main

# 方法 2: 使用 PowerShell 脚本
.\scripts\run_http_server.ps1

# 方法 3: 使用 Uvicorn 命令
uvicorn app.mcp.http_server:http_app --host 0.0.0.0 --port 8001
```

**重要提示：**
- ✅ **使用 Uvicorn** - 完全支持 SSE
- ❌ **不要使用 Gunicorn** - 不支持 SSE 长连接

详细的 HTTP/SSE 配置和测试指南，请参阅：[MCP HTTP SSE Guide](docs/MCP_HTTP_SSE_GUIDE.md)

## 在客户端中配置

### Cline (VSCode) 配置 (HTTP/SSE 模式)

1. 在 VSCode 中安装 Cline 扩展
2. 打开 Cline 设置（`MCP Settings`）
3. 添加以下配置：

```json
{
  "mcpServers": {
    "cmdb-http": {
      "type": "sse",
      "url": "http://localhost:8001/sse"
    }
  }
}
```

**注意：** 确保先启动 HTTP 服务器：`python -m app.mcp.http_main`

### Claude Desktop 配置 (stdio 模式)

#### Windows 配置

编辑 Claude Desktop 配置文件（通常在 `%APPDATA%\Claude\claude_desktop_config.json`）：

```json
{
  "mcpServers": {
    "cmdb-service": {
      "command": "python",
      "args": ["-m", "app.mcp"],
      "cwd": "D:\\github\\cmdb",
      "env": {
        "DATABASE_URL": "mysql+pymysql://user:password@localhost:3306/cmdb?charset=utf8mb4"
      }
    }
  }
}
```

### Linux/Mac 配置

编辑 Claude Desktop 配置文件（通常在 `~/.config/Claude/claude_desktop_config.json`）：

```json
{
  "mcpServers": {
    "cmdb-service": {
      "command": "python",
      "args": ["-m", "app.mcp"],
      "cwd": "/path/to/cmdb",
      "env": {
        "DATABASE_URL": "mysql+pymysql://user:password@localhost:3306/cmdb?charset=utf8mb4"
      }
    }
  }
}
```

### 使用虚拟环境

如果使用虚拟环境，修改 command 和 args：

```json
{
  "mcpServers": {
    "cmdb-service": {
      "command": "D:\\github\\cmdb\\.venv\\Scripts\\python.exe",
      "args": ["-m", "app.mcp"],
      "cwd": "D:\\github\\cmdb"
    }
  }
}
```

## 可用工具

### 产品管理

#### get_product
根据ID获取产品信息

**参数：**
- `id` (integer, 必需): 产品记录ID

**示例：**
```json
{
  "name": "get_product",
  "arguments": {
    "id": 1
  }
}
```

#### list_products
获取产品列表（支持分页）

**参数：**
- `skip` (integer, 可选): 跳过的记录数，默认0
- `limit` (integer, 可选): 返回的记录数，默认100

**示例：**
```json
{
  "name": "list_products",
  "arguments": {
    "skip": 0,
    "limit": 10
  }
}
```

#### create_product
创建新产品

**参数：**
- `product_id` (integer, 必需): 产品ID（唯一）
- `product_name` (string, 必需): 产品名称
- `product_version` (string, 可选): 产品版本
- `product_desc` (string, 可选): 产品描述

**示例：**
```json
{
  "name": "create_product",
  "arguments": {
    "product_id": 1,
    "product_name": "My Product",
    "product_version": "1.0.0",
    "product_desc": "Product description"
  }
}
```

#### update_product
更新产品信息

**参数：**
- `id` (integer, 必需): 产品记录ID
- `product_name` (string, 可选): 产品名称
- `product_version` (string, 可选): 产品版本
- `product_desc` (string, 可选): 产品描述

#### delete_product
删除产品

**参数：**
- `id` (integer, 必需): 产品记录ID

### 标准服务管理

#### get_standard_service
根据ID获取标准服务信息

**参数：**
- `id` (integer, 必需): 服务记录ID

#### list_standard_services
获取标准服务列表（支持分页）

**参数：**
- `skip` (integer, 可选): 跳过的记录数，默认0
- `limit` (integer, 可选): 返回的记录数，默认100

#### create_standard_service
创建标准服务（支持配置验证）

**参数：**
- `service_id` (integer, 必需): 服务ID
- `service_name` (string, 必需): 服务名称
- `component_id` (integer, 必需): 组件ID
- `service_type` (string, 可选): 服务类型（如：redis, nebula）
- `deployment_info` (object, 可选): 部署信息（根据service_type验证）

**示例（Redis配置）：**
```json
{
  "name": "create_standard_service",
  "arguments": {
    "service_id": 1,
    "service_name": "Redis Service",
    "component_id": 1,
    "service_type": "redis",
    "deployment_info": {
      "hostname": "redis9001.eniot.io",
      "user": "root",
      "bin_path": "/usr/local/redis/bin",
      "config_dir": "/data1/redis/7000/conf",
      "log_dir": "/data1/redis/7000/log",
      "forbidden_keywords": ["flushall", "flushdb", "del", "shutdown"]
    }
  }
}
```

**示例（Nebula配置）：**
```json
{
  "name": "create_standard_service",
  "arguments": {
    "service_id": 2,
    "service_name": "Nebula Service",
    "component_id": 1,
    "service_type": "nebula",
    "deployment_info": {
      "hostname": "nebula-graph9001.eniot.io",
      "user": "root",
      "bin_path": "/usr/local/nebula-3.1.0/bin",
      "config_dir": "/usr/local/nebula-3.1.0/etc",
      "log_dir": "/data1/nebula/logs",
      "port": "9669",
      "service_names": ["nebula-graphd", "nebula-storaged", "nebula-metad"],
      "forbidden_keywords": ["drop", "delete", "clear", "remove"]
    }
  }
}
```

### 部署服务管理

#### get_deploy_service
根据ID获取部署服务信息

**参数：**
- `id` (integer, 必需): 部署服务记录ID

#### list_deploy_services
获取部署服务列表（支持分页）

**参数：**
- `skip` (integer, 可选): 跳过的记录数，默认0
- `limit` (integer, 可选): 返回的记录数，默认100

#### create_deploy_service
创建部署服务（支持配置验证）

**参数：**
- `service_id` (integer, 必需): 服务ID
- `service_name` (string, 必需): 服务名称
- `region_id` (integer, 必需): 区域ID
- `component_id` (integer, 必需): 组件ID
- `service_type` (string, 可选): 服务类型（如：redis, nebula）
- `deployment_info` (object, 可选): 部署信息（根据service_type验证）

## 错误处理

MCP Server 会返回 JSON 格式的错误信息：

```json
{
  "error": "Product with identifier '999' not found"
}
```

常见错误：
- `NOT_FOUND`: 资源不存在
- `VALIDATION_ERROR`: 配置验证失败
- `CONFIG_VALIDATION_ERROR`: 产品配置验证失败

## 测试

运行 MCP 测试：

```bash
uv run pytest tests/test_mcp.py -v
```

所有14个MCP测试用例都已通过。

## 注意事项

1. MCP Server 通过 stdio 通信，需要由 MCP 客户端启动
2. 确保数据库连接配置正确（通过环境变量 `DATABASE_URL`）
3. 配置验证会根据 `service_type` 自动选择对应的 schema
4. 所有工具调用都是异步的

