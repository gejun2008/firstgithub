"""基础模型类"""

from sqlalchemy import Column, DateTime, Integer, func

from app.core.database import Base as BaseModel


class Base(BaseModel):
    """抽象基类，包含通用字段"""

    __abstract__ = True

    id = Column(Integer, primary_key=True, autoincrement=True, comment="主键ID")
    create_time = Column(
        DateTime, server_default=func.now(), nullable=False, comment="创建时间"
    )
    update_time = Column(
        DateTime,
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
        comment="更新时间",
    )
