"""监控模型"""
from sqlalchemy import Column, String, Text, Integer, UniqueConstraint, Index
from app.models.base import Base


class ServiceMonitoringIndex(Base):
    """服务监控指标表"""
    __tablename__ = 't_service_monitoring_index'
    
    product_name = Column(String(100), nullable=False, comment='产品名称')
    service_name = Column(String(100), nullable=False, comment='服务名称')
    monitoring_index_name = Column(String(100), nullable=False, comment='监控指标名称')
    monitoring_index_desc = Column(Text, nullable=True, comment='监控指标描述')
    monitoring_index_threshold = Column(String(200), nullable=True, comment='监控指标阈值')
    monitoring_unit = Column(String(50), nullable=True, comment='监控单位')
    alert_level = Column(String(20), nullable=True, comment='告警级别')
    is_enabled = Column(Integer, default=1, comment='是否启用')
    
    __table_args__ = (
        UniqueConstraint('product_name', 'service_name', 'monitoring_index_name', name='uk_product_service_index'),
        Index('idx_monitoring_product_name', 'product_name'),
        Index('idx_monitoring_service_name', 'service_name'),
        Index('idx_monitoring_index_name', 'monitoring_index_name'),
        Index('idx_monitoring_alert_level', 'alert_level'),
        Index('idx_monitoring_is_enabled', 'is_enabled'),
        {'comment': '服务监控指标表'}
    )

