"""虚拟机模型"""
from sqlalchemy import Column, SmallInteger, String, Integer, JSON, Index
from app.models.base import Base


class VirtualMachine(Base):
    """虚拟机信息表"""
    __tablename__ = 'virtual_machines'
    
    vm_name = Column(String(100), nullable=False, comment='虚拟机名称')
    service_id = Column(String(100), nullable=True, comment='服务ID')
    region_id = Column(SmallInteger, nullable=True, comment='区域ID')
    vm_ip_address = Column(String(50), nullable=True, comment='虚拟机IP地址')
    vm_status = Column(String(20), nullable=True, comment='虚拟机状态')
    vm_server_name = Column(String(100), nullable=True, comment='虚拟机服务器名称')
    vm_type = Column(String(50), nullable=True, comment='虚拟机类型')
    vm_specification = Column(String(100), nullable=True, comment='虚拟机规格')
    vm_cpu_cores = Column(Integer, nullable=True, comment='CPU核心数')
    vm_memory = Column(Integer, nullable=True, comment='内存大小(GB)')
    vm_os = Column(String(50), nullable=True, comment='操作系统')
    vm_os_edition = Column(String(50), nullable=True, comment='操作系统版本')
    virtualization_platform = Column(String(50), nullable=True, comment='虚拟化平台')
    vm_security_zone = Column(String(50), nullable=True, comment='安全区域')
    system_disk_type = Column(String(50), nullable=True, comment='系统盘类型')
    system_disk_size = Column(Integer, nullable=True, comment='系统盘大小(GiB)')
    data_disk = Column(JSON, nullable=True, comment='数据盘')
    vpc_name = Column(String(100), nullable=True, comment='VPC名称')
    subnet_name = Column(String(100), nullable=True, comment='子网名称')
    vm_owner = Column(String(100), nullable=True, comment='虚拟机负责人')
    
    __table_args__ = (
        Index('idx_vm_name', 'vm_name'),
        Index('idx_vm_region_id', 'region_id'),
        Index('idx_vm_service_id', 'service_id'),
        Index('idx_vm_status', 'vm_status'),
        Index('idx_vm_owner', 'vm_owner'),
        {'comment': '虚拟机信息表'}
    )

