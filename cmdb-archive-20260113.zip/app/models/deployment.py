"""部署相关模型"""
from sqlalchemy import Column, SmallInteger, String, DateTime, Index, ForeignKey
from sqlalchemy.orm import relationship
from app.models.base import Base


class DeployProduct(Base):
    """产品部署表"""
    __tablename__ = 'deploy_products'
    
    deploy_id = Column(String(50), nullable=False, unique=True, comment='部署ID')
    region_name = Column(String(100), nullable=False, comment='区域名称')
    region_id = Column(SmallInteger, ForeignKey('regions.region_id', ondelete='CASCADE'), nullable=False, comment='区域ID')
    product_id = Column(String(50), nullable=False, comment='产品ID')  # 注意：类型不一致，不设外键
    deploy_status = Column(String(20), default='pending', comment='部署状态')
    deploy_time = Column(DateTime, nullable=True, comment='部署时间')
    deploy_operator = Column(String(100), nullable=True, comment='部署操作人')
    
    # 关系
    region = relationship('Region', backref='deploy_products')
    
    __table_args__ = (
        Index('idx_deploy_products_region_name', 'region_name'),
        Index('idx_deploy_products_product_id', 'product_id'),
        Index('idx_deploy_products_status', 'deploy_status'),
        {'comment': '产品部署表'}
    )

