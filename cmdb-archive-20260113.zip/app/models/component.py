"""组件模型"""
from sqlalchemy import Column, Integer, SmallInteger, String, Text, JSON, Index, ForeignKey
from sqlalchemy.orm import relationship
from app.models.base import Base


class StandardComponent(Base):
    """标准组件表"""
    __tablename__ = 'standard_component'
    
    component_id = Column(Integer, nullable=False, unique=True, comment='组件ID')
    component_name = Column(String(100), nullable=False, comment='组件名称')
    product_id = Column(SmallInteger, ForeignKey('products.product_id', ondelete='CASCADE'), nullable=False, comment='产品ID')
    parent_component_id = Column(Integer, nullable=True, comment='父组件ID')
    component_alias = Column(String(100), nullable=True, comment='组件别名')
    component_version = Column(String(50), nullable=True, comment='组件版本')
    component_desc = Column(Text, nullable=True, comment='组件描述')
    component_type = Column(String(50), nullable=True, comment='组件类型')
    deployment_dependencies = Column(JSON, nullable=True, comment='部署依赖')
    call_dependencies = Column(Text, nullable=True, comment='调用依赖')
    deployment_information = Column(JSON, nullable=True, comment='部署信息')
    is_active = Column(Integer, default=1, comment='是否激活')
    
    # 关系
    product = relationship('Product', backref='standard_components')
    
    __table_args__ = (
        Index('idx_standard_component_name', 'component_name'),
        Index('idx_standard_component_product_id', 'product_id'),
        Index('idx_standard_parent_component_id', 'parent_component_id'),
        Index('idx_standard_component_type', 'component_type'),
        {'comment': '标准组件表'}
    )


class DeployComponent(Base):
    """部署组件表"""
    __tablename__ = 'deploy_component'
    
    component_id = Column(Integer, nullable=False, comment='组件ID')
    component_name = Column(String(100), nullable=False, comment='组件名称')
    region_id = Column(SmallInteger, ForeignKey('regions.region_id', ondelete='CASCADE'), nullable=False, comment='区域ID')
    action = Column(Integer, nullable=True, comment='操作类型')
    product_id = Column(Integer, nullable=False, comment='产品ID')  # 注意：这里不设外键，因为类型不一致
    parent_component_id = Column(String(50), nullable=True, comment='父组件ID')
    component_alias = Column(String(100), nullable=True, comment='组件别名')
    component_version = Column(String(50), nullable=True, comment='组件版本')
    component_desc = Column(Text, nullable=True, comment='组件描述')
    component_type = Column(String(50), nullable=True, comment='组件类型')
    deployment_dependencies = Column(JSON, nullable=True, comment='部署依赖')
    call_dependencies = Column(Text, nullable=True, comment='调用依赖')
    deployment_information = Column(JSON, nullable=True, comment='部署信息')
    deploy_status = Column(String(20), default='pending', comment='部署状态')
    
    # 关系（手动处理，因为product_id类型不一致）
    region = relationship('Region', backref='deploy_components')
    
    __table_args__ = (
        Index('idx_deploy_component_id', 'component_id'),
        Index('idx_deploy_component_region_id', 'region_id'),
        Index('idx_deploy_component_product_id', 'product_id'),
        Index('idx_deploy_parent_component_id', 'parent_component_id'),
        Index('idx_deploy_component_type', 'component_type'),
        {'comment': '部署组件表'}
    )

