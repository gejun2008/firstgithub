"""产品模型"""
from sqlalchemy import Column, SmallInteger, String, Text, UniqueConstraint, Index
from app.models.base import Base


class Product(Base):
    """产品信息表"""
    __tablename__ = 'products'
    
    product_id = Column(SmallInteger, nullable=False, unique=True, comment='产品ID')
    product_name = Column(String(100), nullable=False, comment='产品名称')
    product_version = Column(String(50), nullable=True, comment='产品版本')
    product_desc = Column(Text, nullable=True, comment='产品描述')
    
    __table_args__ = (
        Index('idx_product_name', 'product_name'),
        {'comment': '产品信息表'}
    )

