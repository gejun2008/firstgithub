"""区域模型"""
from sqlalchemy import Column, SmallInteger, String, Text, UniqueConstraint, Index
from app.models.base import Base


class Region(Base):
    """区域信息表"""
    __tablename__ = 'regions'
    
    region_id = Column(SmallInteger, nullable=False, unique=True, comment='区域ID')
    region_name = Column(String(100), nullable=False, comment='区域名称')
    region_desc = Column(Text, nullable=True, comment='区域描述')
    pm_owner = Column(String(100), nullable=True, comment='产品负责人')
    gtm_owner = Column(String(100), nullable=True, comment='GTM负责人')
    op_owner = Column(String(100), nullable=True, comment='运维负责人')
    
    __table_args__ = (
        Index('idx_region_name', 'region_name'),
        {'comment': '区域信息表'}
    )

