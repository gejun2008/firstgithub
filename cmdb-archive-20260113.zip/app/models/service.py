"""服务模型"""
from sqlalchemy import Column, Integer, SmallInteger, String, Text, JSON, Numeric, Index, ForeignKey
from sqlalchemy.orm import relationship
from app.models.base import Base


class StandardService(Base):
    """标准服务表"""
    __tablename__ = 'standard_services'
    
    service_id = Column(Integer, nullable=False, unique=True, comment='服务ID')
    service_name = Column(String(100), nullable=False, comment='服务名称')
    component_id = Column(Integer, nullable=False, comment='组件ID')
    service_desc = Column(Text, nullable=True, comment='服务描述')
    service_version = Column(String(50), nullable=True, comment='服务版本')
    service_type = Column(String(50), nullable=True, comment='服务类型')
    deployment_type = Column(String(50), nullable=True, comment='部署类型')
    deployment_info = Column(JSON, nullable=True, comment='部署信息')
    cpu_request_value = Column(Numeric(10, 2), nullable=True, comment='CPU请求值')
    cpu_limit_value = Column(Numeric(10, 2), nullable=True, comment='CPU限制值')
    memory_request_value = Column(Integer, nullable=True, comment='内存请求值(MB)')
    memory_limit_value = Column(Integer, nullable=True, comment='内存限制值(MB)')
    owner = Column(String(100), nullable=True, comment='负责人')
    self_inspection_logic = Column(Text, nullable=True, comment='自检逻辑')
    is_active = Column(Integer, default=1, comment='是否激活')
    
    __table_args__ = (
        Index('idx_standard_service_name', 'service_name'),
        Index('idx_standard_component_id', 'component_id'),
        Index('idx_standard_service_type', 'service_type'),
        Index('idx_standard_owner', 'owner'),
        {'comment': '标准服务表'}
    )


class DeployService(Base):
    """部署服务表"""
    __tablename__ = 'deploy_services'
    
    service_id = Column(Integer, nullable=False, comment='服务ID')
    service_name = Column(String(100), nullable=False, comment='服务名称')
    region_id = Column(Integer, nullable=False, comment='区域ID')  # 注意：类型不一致，不设外键
    action = Column(Integer, nullable=True, comment='操作类型')
    component_id = Column(Integer, nullable=False, comment='组件ID')
    service_desc = Column(Text, nullable=True, comment='服务描述')
    service_version = Column(String(50), nullable=True, comment='服务版本')
    service_type = Column(String(50), nullable=True, comment='服务类型')
    deployment_type = Column(String(50), nullable=True, comment='部署类型')
    deployment_info = Column(JSON, nullable=True, comment='部署信息')
    cpu_request_value = Column(Numeric(10, 2), nullable=True, comment='CPU请求值')
    cpu_limit_value = Column(Numeric(10, 2), nullable=True, comment='CPU限制值')
    memory_request_value = Column(Integer, nullable=True, comment='内存请求值(MB)')
    memory_limit_value = Column(Integer, nullable=True, comment='内存限制值(MB)')
    owner = Column(String(100), nullable=True, comment='负责人')
    self_inspection_logic = Column(Text, nullable=True, comment='自检逻辑')
    deploy_status = Column(String(20), default='pending', comment='部署状态')
    health_status = Column(String(20), default='unknown', comment='健康状态')
    
    __table_args__ = (
        Index('idx_deploy_service_service_id', 'service_id'),
        Index('idx_deploy_service_service_name', 'service_name'),
        Index('idx_deploy_service_region_id', 'region_id'),
        Index('idx_deploy_service_component_id', 'component_id'),
        Index('idx_deploy_service_type', 'service_type'),
        Index('idx_deploy_service_owner', 'owner'),
        Index('idx_deploy_service_status', 'deploy_status'),
        {'comment': '部署服务表'}
    )

