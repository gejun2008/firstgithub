"""GraphQL Schema定义"""

from typing import List, Optional

import strawberry
from sqlalchemy.orm import Session

from app.api.graphql.resolvers.product_resolver import to_product_graphql
from app.api.graphql.resolvers.service_resolver import (
    to_deploy_service_graphql,
    to_standard_service_graphql,
)
from app.api.graphql.types.product_type import Product
from app.api.graphql.types.service_type import DeployService, StandardService
from app.core.database import SessionLocal
from app.services.product_service import ProductService
from app.services.service_service import DeployServiceService, StandardServiceService


def get_db_session() -> Session:
    """获取数据库会话（用于GraphQL）"""
    db = SessionLocal()
    try:
        return db
    except Exception:
        db.close()
        raise


@strawberry.type
class Query:
    """GraphQL查询"""

    @strawberry.field
    def product(self, id: int) -> Optional[Product]:
        """根据ID获取产品"""
        db = get_db_session()
        try:
            service = ProductService(db)
            product = service.get_by_id(id)
            return to_product_graphql(product)
        finally:
            db.close()

    @strawberry.field
    def products(self, skip: int = 0, limit: int = 100) -> List[Product]:
        """获取所有产品"""
        db = get_db_session()
        try:
            service = ProductService(db)
            products = service.get_all(skip, limit)
            return [to_product_graphql(p) for p in products]
        finally:
            db.close()

    @strawberry.field
    def standard_service(self, id: int) -> Optional[StandardService]:
        """根据ID获取标准服务"""
        db = get_db_session()
        try:
            service = StandardServiceService(db)
            svc = service.get_by_id(id)
            return to_standard_service_graphql(svc)
        finally:
            db.close()

    @strawberry.field
    def standard_services(
        self, skip: int = 0, limit: int = 100
    ) -> List[StandardService]:
        """获取所有标准服务"""
        db = get_db_session()
        try:
            service = StandardServiceService(db)
            services = service.get_all(skip, limit)
            return [to_standard_service_graphql(s) for s in services]
        finally:
            db.close()

    @strawberry.field
    def deploy_service(self, id: int) -> Optional[DeployService]:
        """根据ID获取部署服务"""
        db = get_db_session()
        try:
            service = DeployServiceService(db)
            svc = service.get_by_id(id)
            return to_deploy_service_graphql(svc)
        finally:
            db.close()

    @strawberry.field
    def deploy_services(self, skip: int = 0, limit: int = 100) -> List[DeployService]:
        """获取所有部署服务"""
        db = get_db_session()
        try:
            service = DeployServiceService(db)
            services = service.get_all(skip, limit)
            return [to_deploy_service_graphql(s) for s in services]
        finally:
            db.close()


# 创建GraphQL Schema
schema = strawberry.Schema(query=Query)
