"""服务Resolver"""
from typing import List, Optional
from sqlalchemy.orm import Session
from app.models.service import StandardService as StandardServiceModel, DeployService as DeployServiceModel
from app.api.graphql.types.service_type import StandardService, DeployService
from app.services.service_service import StandardServiceService, DeployServiceService
from app.api.graphql.resolvers.config_resolver import resolve_service_config


def to_standard_service_graphql(model: StandardServiceModel) -> StandardService:
    """将模型转换为GraphQL类型"""
    return StandardService(
        id=model.id,
        service_id=model.service_id,
        service_name=model.service_name,
        component_id=model.component_id,
        service_desc=model.service_desc,
        service_version=model.service_version,
        service_type=model.service_type,
        deployment_type=model.deployment_type,
        deployment_info=resolve_service_config(
            model.deployment_info,
            service_type=model.service_type
        ) if model.deployment_info else None,
        cpu_request_value=float(model.cpu_request_value) if model.cpu_request_value else None,
        cpu_limit_value=float(model.cpu_limit_value) if model.cpu_limit_value else None,
        memory_request_value=model.memory_request_value,
        memory_limit_value=model.memory_limit_value,
        owner=model.owner,
        is_active=model.is_active
    )


def to_deploy_service_graphql(model: DeployServiceModel) -> DeployService:
    """将模型转换为GraphQL类型"""
    return DeployService(
        id=model.id,
        service_id=model.service_id,
        service_name=model.service_name,
        region_id=model.region_id,
        component_id=model.component_id,
        service_desc=model.service_desc,
        service_version=model.service_version,
        service_type=model.service_type,
        deployment_type=model.deployment_type,
        deployment_info=resolve_service_config(
            model.deployment_info,
            service_type=model.service_type
        ) if model.deployment_info else None,
        cpu_request_value=float(model.cpu_request_value) if model.cpu_request_value else None,
        cpu_limit_value=float(model.cpu_limit_value) if model.cpu_limit_value else None,
        memory_request_value=model.memory_request_value,
        memory_limit_value=model.memory_limit_value,
        owner=model.owner,
        deploy_status=model.deploy_status,
        health_status=model.health_status
    )

