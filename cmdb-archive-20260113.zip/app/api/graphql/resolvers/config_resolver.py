"""配置类型解析器"""
from typing import Optional, Dict, Any
from app.api.graphql.types.config_types import (
    RedisConfigType,
    NebulaConfigType,
    DefaultConfigType,
    ServiceConfig
)
from app.services.config_schemas import ProductType
import json


def resolve_service_config(
    deployment_info: Optional[Dict[str, Any]],
    service_type: Optional[str] = None,
    product_type: Optional[str] = None
) -> Optional[ServiceConfig]:
    """
    根据service_type或product_type解析配置类型
    
    Args:
        deployment_info: 部署信息字典
        service_type: 服务类型
        product_type: 产品类型
        
    Returns:
        解析后的配置类型，如果deployment_info为None则返回None
    """
    if not deployment_info:
        return None
    
    # 确定配置类型
    config_type = (service_type or product_type or "").lower()
    
    try:
        if config_type == ProductType.REDIS:
            return RedisConfigType(**deployment_info)
        elif config_type == ProductType.NEBULA:
            return NebulaConfigType(**deployment_info)
        else:
            # 默认类型：返回JSON字符串
            return DefaultConfigType(raw_data=json.dumps(deployment_info))
    except Exception:
        # 如果解析失败，返回默认类型
        return DefaultConfigType(raw_data=json.dumps(deployment_info))

