"""产品Resolver"""
from typing import List
from app.models.product import Product as ProductModel
from app.api.graphql.types.product_type import Product


def to_product_graphql(model: ProductModel) -> Product:
    """将模型转换为GraphQL类型"""
    return Product(
        id=model.id,
        product_id=model.product_id,
        product_name=model.product_name,
        product_version=model.product_version,
        product_desc=model.product_desc
    )

