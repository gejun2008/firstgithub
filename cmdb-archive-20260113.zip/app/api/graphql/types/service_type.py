"""GraphQL服务类型"""
import strawberry
from typing import Optional
from app.api.graphql.types.config_types import ServiceConfig
import json


@strawberry.type
class StandardService:
    """标准服务类型"""
    id: int
    service_id: int
    service_name: str
    component_id: int
    service_desc: Optional[str] = None
    service_version: Optional[str] = None
    service_type: Optional[str] = None
    deployment_type: Optional[str] = None
    deployment_info: Optional[ServiceConfig] = None
    cpu_request_value: Optional[float] = None
    cpu_limit_value: Optional[float] = None
    memory_request_value: Optional[int] = None
    memory_limit_value: Optional[int] = None
    owner: Optional[str] = None
    is_active: Optional[int] = None


@strawberry.type
class DeployService:
    """部署服务类型"""
    id: int
    service_id: int
    service_name: str
    region_id: int
    component_id: int
    service_desc: Optional[str] = None
    service_version: Optional[str] = None
    service_type: Optional[str] = None
    deployment_type: Optional[str] = None
    deployment_info: Optional[ServiceConfig] = None
    cpu_request_value: Optional[float] = None
    cpu_limit_value: Optional[float] = None
    memory_request_value: Optional[int] = None
    memory_limit_value: Optional[int] = None
    owner: Optional[str] = None
    deploy_status: Optional[str] = None
    health_status: Optional[str] = None

