"""GraphQL产品类型"""
import strawberry
from typing import Optional


@strawberry.type
class Product:
    """产品类型"""
    id: int
    product_id: int
    product_name: str
    product_version: Optional[str] = None
    product_desc: Optional[str] = None

