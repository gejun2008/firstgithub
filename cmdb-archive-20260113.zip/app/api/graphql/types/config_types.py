"""GraphQL配置类型定义"""
import strawberry
from typing import List, Optional


@strawberry.type
class RedisConfigType:
    """Redis配置类型"""
    hostname: str
    user: str
    bin_path: str
    config_dir: str
    log_dir: str
    forbidden_keywords: List[str]


@strawberry.type
class NebulaConfigType:
    """Nebula Graph配置类型"""
    hostname: str
    user: str
    bin_path: str
    config_dir: str
    log_dir: str
    port: str
    service_names: List[str]
    forbidden_keywords: List[str]


@strawberry.type
class DefaultConfigType:
    """默认配置类型（通用JSON）"""
    raw_data: str  # JSON字符串


# 定义Union类型
ServiceConfig = strawberry.union(
    "ServiceConfig",
    types=(RedisConfigType, NebulaConfigType, DefaultConfigType)
)

