"""基础Repository类"""

from typing import Generic, List, Optional, Type, TypeVar

from sqlalchemy.orm import Session

from app.core.exceptions import NotFoundError

ModelType = TypeVar("ModelType")


class BaseRepository(Generic[ModelType]):
    """基础Repository，提供通用CRUD操作"""

    def __init__(self, model: Type[ModelType], db: Session):
        """
        Args:
            model: SQLAlchemy模型类
            db: 数据库会话
        """
        self.model = model
        self.db = db

    def get_by_id(self, id: int) -> Optional[ModelType]:
        """根据ID获取记录"""
        return self.db.query(self.model).filter(self.model.id == id).first()

    def get_by_id_or_raise(self, id: int, resource_name: str = "Resource") -> ModelType:
        """根据ID获取记录，不存在则抛出异常"""
        obj = self.get_by_id(id)
        if not obj:
            raise NotFoundError(resource_name, str(id))
        return obj

    def get_all(self, skip: int = 0, limit: int = 100) -> List[ModelType]:
        """获取所有记录（分页）"""
        return self.db.query(self.model).offset(skip).limit(limit).all()

    def get_by_filter(self, **filters) -> List[ModelType]:
        """根据过滤条件获取记录"""
        query = self.db.query(self.model)
        for key, value in filters.items():
            if hasattr(self.model, key):
                query = query.filter(getattr(self.model, key) == value)
        return query.all()

    def create(self, **kwargs) -> ModelType:
        """创建新记录"""
        obj = self.model(**kwargs)
        self.db.add(obj)
        self.db.commit()
        self.db.refresh(obj)
        return obj

    def update(self, id: int, **kwargs) -> ModelType:
        """更新记录"""
        obj = self.get_by_id_or_raise(id, self.model.__name__)
        for key, value in kwargs.items():
            if hasattr(obj, key):
                setattr(obj, key, value)
        self.db.commit()
        self.db.refresh(obj)
        return obj

    def delete(self, id: int) -> bool:
        """删除记录"""
        obj = self.get_by_id_or_raise(id, self.model.__name__)
        self.db.delete(obj)
        self.db.commit()
        return True
