"""服务Repository"""
from typing import Optional, List
from sqlalchemy.orm import Session
from app.models.service import StandardService, DeployService
from app.repositories.base_repository import BaseRepository


class StandardServiceRepository(BaseRepository[StandardService]):
    """标准服务数据访问层"""
    
    def __init__(self, db: Session):
        super().__init__(StandardService, db)
    
    def get_by_service_id(self, service_id: int) -> Optional[StandardService]:
        """根据service_id获取服务"""
        return self.db.query(StandardService).filter(
            StandardService.service_id == service_id
        ).first()
    
    def get_by_name(self, service_name: str) -> List[StandardService]:
        """根据服务名称获取服务列表"""
        return self.db.query(StandardService).filter(
            StandardService.service_name == service_name
        ).all()


class DeployServiceRepository(BaseRepository[DeployService]):
    """部署服务数据访问层"""
    
    def __init__(self, db: Session):
        super().__init__(DeployService, db)
    
    def get_by_service_id(self, service_id: int) -> Optional[DeployService]:
        """根据service_id获取部署服务"""
        return self.db.query(DeployService).filter(
            DeployService.service_id == service_id
        ).first()
    
    def get_by_service_type(self, service_type: str) -> List[DeployService]:
        """根据服务类型获取部署服务列表"""
        return self.db.query(DeployService).filter(
            DeployService.service_type == service_type
        ).all()

