"""产品Repository"""
from typing import Optional
from sqlalchemy.orm import Session
from app.models.product import Product
from app.repositories.base_repository import BaseRepository


class ProductRepository(BaseRepository[Product]):
    """产品数据访问层"""
    
    def __init__(self, db: Session):
        super().__init__(Product, db)
    
    def get_by_product_id(self, product_id: int) -> Optional[Product]:
        """根据product_id获取产品"""
        return self.db.query(Product).filter(Product.product_id == product_id).first()
    
    def get_by_name(self, product_name: str) -> Optional[Product]:
        """根据产品名称获取产品"""
        return self.db.query(Product).filter(Product.product_name == product_name).first()

