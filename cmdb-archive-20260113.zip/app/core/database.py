"""数据库连接和会话管理"""

import os
from typing import Generator

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import Session, sessionmaker

from app.core.config import settings

# 设置环境变量中的代理
os.environ["HTTP_PROXY"] = settings.HTTP_PROXY
os.environ["HTTPS_PROXY"] = settings.HTTPS_PROXY
os.environ["http_proxy"] = settings.HTTP_PROXY
os.environ["https_proxy"] = settings.HTTPS_PROXY

# 创建数据库引擎，配置代理支持
engine = create_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,  # 连接前检查连接是否有效
    pool_recycle=3600,  # 1小时后回收连接
    echo=settings.DEBUG,  # 调试模式下打印SQL
    connect_args={
        "autocommit": False,
    },
)

# 创建会话工厂
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# 创建基础模型类
Base = declarative_base()


def get_db() -> Generator[Session, None, None]:
    """
    获取数据库会话的依赖注入函数
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
