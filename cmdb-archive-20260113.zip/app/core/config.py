"""应用配置"""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """应用配置类"""

    # 应用配置
    APP_NAME: str = "CMDB Service"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False

    # 数据库配置
    DATABASE_URL: str = "mysql+pymysql://root:!W37%23WPP%40%2BC%24@10.65.166.35:3306/cmdb?charset=utf8mb4"

    # MySQL 连接超时（秒）
    MYSQL_CONNECT_TIMEOUT: int = 5
    MYSQL_READ_TIMEOUT: int = 30
    MYSQL_WRITE_TIMEOUT: int = 30

    # HTTP 代理配置
    HTTP_PROXY: str = "http://10.10.10.10:10634"
    HTTPS_PROXY: str = "http://10.10.10.10:10634"

    # 日志配置
    LOG_LEVEL: str = "INFO"

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
