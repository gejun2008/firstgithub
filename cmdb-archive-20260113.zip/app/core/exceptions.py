"""自定义异常类"""
from typing import Optional


class CMDBException(Exception):
    """CMDB基础异常类"""
    def __init__(self, message: str, code: Optional[str] = None):
        self.message = message
        self.code = code
        super().__init__(self.message)


class NotFoundError(CMDBException):
    """资源未找到异常"""
    def __init__(self, resource: str, identifier: str):
        super().__init__(
            f"{resource} with identifier '{identifier}' not found",
            code="NOT_FOUND"
        )


class ValidationError(CMDBException):
    """验证错误"""
    def __init__(self, message: str, field: Optional[str] = None):
        self.field = field
        super().__init__(message, code="VALIDATION_ERROR")


class ConfigValidationError(ValidationError):
    """配置验证错误"""
    def __init__(self, message: str, config_type: Optional[str] = None):
        self.config_type = config_type
        super().__init__(message, field="deployment_info")

