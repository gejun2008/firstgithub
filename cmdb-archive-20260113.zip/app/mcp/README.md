# MCP Server Wrapper

CMDB Service 的 MCP (Model Context Protocol) 封装，将微服务功能暴露为 MCP 工具。

## 功能

MCP Server 提供了以下工具：

### 产品管理
- `get_product`: 根据ID获取产品信息
- `list_products`: 获取产品列表（支持分页）
- `create_product`: 创建新产品
- `update_product`: 更新产品信息
- `delete_product`: 删除产品

### 标准服务管理
- `get_standard_service`: 根据ID获取标准服务信息
- `list_standard_services`: 获取标准服务列表（支持分页）
- `create_standard_service`: 创建标准服务（支持Redis、Nebula等配置验证）

### 部署服务管理
- `get_deploy_service`: 根据ID获取部署服务信息
- `list_deploy_services`: 获取部署服务列表（支持分页）
- `create_deploy_service`: 创建部署服务（支持Redis、Nebula等配置验证）

## 运行 MCP Server

```bash
# stdio 传输 (Claude Desktop)
python -m app.mcp

# Streamable HTTP 传输 (Cline)
uvicorn app.mcp:http_app --host 127.0.0.1 --port 8001
```
## 测试

运行 MCP 测试：

```bash
uv run pytest tests/test_mcp.py -v
```

## 使用示例

### 在 Claude Desktop 中配置

在 Claude Desktop 的配置文件中添加：

```json
{
  "mcpServers": {
    "cmdb-service": {
      "command": "python",
      "args": ["-m", "app.mcp"],
      "env": {
        "DATABASE_URL": "mysql+pymysql://user:password@localhost:3306/cmdb"
      }
    }
  }
}
```

### 工具调用示例

通过 MCP 客户端调用工具：

```python
# 获取产品
result = await mcp_client.call_tool("get_product", {"id": 1})

# 创建产品
result = await mcp_client.call_tool("create_product", {
    "product_id": 1,
    "product_name": "My Product",
    "product_version": "1.0.0"
})

# 创建带Redis配置的服务
result = await mcp_client.call_tool("create_standard_service", {
    "service_id": 1,
    "service_name": "Redis Service",
    "component_id": 1,
    "service_type": "redis",
    "deployment_info": {
        "hostname": "redis9001.eniot.io",
        "user": "root",
        "bin_path": "/usr/local/redis/bin",
        "config_dir": "/data1/redis/7000/conf",
        "log_dir": "/data1/redis/7000/log",
        "forbidden_keywords": ["flushall", "flushdb"]
    }
})
```

## 配置验证

MCP Server 支持不同产品类型的配置验证：

- **Redis**: 验证 hostname, user, bin_path, config_dir, log_dir, forbidden_keywords
- **Nebula**: 验证 hostname, user, bin_path, config_dir, log_dir, port, service_names, forbidden_keywords
- **默认**: 其他类型使用通用JSON格式

配置验证失败时会返回错误信息。

