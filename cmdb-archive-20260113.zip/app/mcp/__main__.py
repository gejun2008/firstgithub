"""MCP Server 入口点

使用方式:
    # stdio 传输 (默认，用于 Claude Desktop)
    python -m app.mcp

    # SSE 传输
    python -m app.mcp --transport sse

    # Streamable HTTP 传输
    python -m app.mcp --transport streamable-http

    # 或直接用 uvicorn 启动 HTTP 服务
    uvicorn app.mcp:http_app --host 127.0.0.1 --port 8001
"""

import sys

from app.mcp.server import mcp


def main():
    transport = "stdio"
    if "--transport" in sys.argv:
        idx = sys.argv.index("--transport")
        if idx + 1 < len(sys.argv):
            transport = sys.argv[idx + 1]

    if transport == "streamable-http":
        print("💡 For HTTP transport, use: uvicorn app.mcp:http_app --port 8001")

    mcp.run(transport=transport)


if __name__ == "__main__":
    main()
