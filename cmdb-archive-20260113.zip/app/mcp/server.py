"""MCP Server实现

Run with stdio transport (default, for Claude Desktop):
  python -m app.mcp

Run with SSE transport:
  python -m app.mcp --transport sse

Run with Streamable HTTP transport:
  python -m app.mcp --transport streamable-http

Or run the HTTP app directly with Uvicorn:
  uvicorn app.mcp.server:http_app --host 127.0.0.1 --port 8001
"""

import json

from mcp.server.fastmcp import FastMCP
from sqlalchemy.orm import Session

from app.core.database import SessionLocal
from app.core.exceptions import NotFoundError, ValidationError
from app.services.product_service import ProductService
from app.services.service_service import DeployServiceService, StandardServiceService

# 创建 FastMCP 服务器实例
mcp = FastMCP("cmdb-service")


def get_db_session() -> Session:
    """获取数据库会话"""
    db = SessionLocal()
    return db


# ==================== 产品管理工具 ====================


@mcp.tool()
def get_product(id: int) -> str:
    """根据ID获取产品信息

    Args:
        id: 产品记录ID
    """
    db = get_db_session()
    try:
        service = ProductService(db)
        product = service.get_by_id(id)
        result = {
            "id": product.id,
            "product_id": product.product_id,
            "product_name": product.product_name,
            "product_version": product.product_version,
            "product_desc": product.product_desc,
        }
        return json.dumps(result, ensure_ascii=False, indent=2)
    except NotFoundError as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    finally:
        db.close()


@mcp.tool()
def list_products(skip: int = 0, limit: int = 100) -> str:
    """获取产品列表（支持分页）

    Args:
        skip: 跳过的记录数
        limit: 返回的记录数
    """
    db = get_db_session()
    try:
        service = ProductService(db)
        products = service.get_all(skip, limit)
        result = [
            {
                "id": p.id,
                "product_id": p.product_id,
                "product_name": p.product_name,
                "product_version": p.product_version,
                "product_desc": p.product_desc,
            }
            for p in products
        ]
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    finally:
        db.close()


@mcp.tool()
def create_product(
    product_id: int,
    product_name: str,
    product_version: str = None,
    product_desc: str = None,
) -> str:
    """创建新产品

    Args:
        product_id: 产品ID（唯一）
        product_name: 产品名称
        product_version: 产品版本（可选）
        product_desc: 产品描述（可选）
    """
    db = get_db_session()
    try:
        service = ProductService(db)
        product = service.create(
            product_id=product_id,
            product_name=product_name,
            product_version=product_version,
            product_desc=product_desc,
        )
        result = {
            "id": product.id,
            "product_id": product.product_id,
            "product_name": product.product_name,
            "product_version": product.product_version,
            "product_desc": product.product_desc,
        }
        return json.dumps(result, ensure_ascii=False, indent=2)
    except ValidationError as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    finally:
        db.close()


@mcp.tool()
def update_product(
    id: int,
    product_name: str = None,
    product_version: str = None,
    product_desc: str = None,
) -> str:
    """更新产品信息

    Args:
        id: 产品记录ID
        product_name: 产品名称（可选）
        product_version: 产品版本（可选）
        product_desc: 产品描述（可选）
    """
    db = get_db_session()
    try:
        service = ProductService(db)
        update_data = {}
        if product_name is not None:
            update_data["product_name"] = product_name
        if product_version is not None:
            update_data["product_version"] = product_version
        if product_desc is not None:
            update_data["product_desc"] = product_desc

        product = service.update(id, **update_data)
        result = {
            "id": product.id,
            "product_id": product.product_id,
            "product_name": product.product_name,
            "product_version": product.product_version,
            "product_desc": product.product_desc,
        }
        return json.dumps(result, ensure_ascii=False, indent=2)
    except NotFoundError as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    finally:
        db.close()


@mcp.tool()
def delete_product(id: int) -> str:
    """删除产品

    Args:
        id: 产品记录ID
    """
    db = get_db_session()
    try:
        service = ProductService(db)
        success = service.delete(id)
        return json.dumps({"success": success}, ensure_ascii=False)
    except NotFoundError as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    finally:
        db.close()


# ==================== 标准服务管理工具 ====================


@mcp.tool()
def get_standard_service(id: int) -> str:
    """根据ID获取标准服务信息

    Args:
        id: 服务记录ID
    """
    db = get_db_session()
    try:
        service = StandardServiceService(db)
        svc = service.get_by_id(id)
        result = {
            "id": svc.id,
            "service_id": svc.service_id,
            "service_name": svc.service_name,
            "component_id": svc.component_id,
            "service_type": svc.service_type,
            "deployment_info": svc.deployment_info,
            "cpu_request_value": float(svc.cpu_request_value)
            if svc.cpu_request_value
            else None,
            "cpu_limit_value": float(svc.cpu_limit_value)
            if svc.cpu_limit_value
            else None,
            "memory_request_value": svc.memory_request_value,
            "memory_limit_value": svc.memory_limit_value,
            "owner": svc.owner,
        }
        return json.dumps(result, ensure_ascii=False, indent=2)
    except NotFoundError as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    finally:
        db.close()


@mcp.tool()
def list_standard_services(skip: int = 0, limit: int = 100) -> str:
    """获取标准服务列表（支持分页）

    Args:
        skip: 跳过的记录数
        limit: 返回的记录数
    """
    db = get_db_session()
    try:
        service = StandardServiceService(db)
        services = service.get_all(skip, limit)
        result = [
            {
                "id": s.id,
                "service_id": s.service_id,
                "service_name": s.service_name,
                "component_id": s.component_id,
                "service_type": s.service_type,
                "deployment_info": s.deployment_info,
                "owner": s.owner,
            }
            for s in services
        ]
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    finally:
        db.close()


@mcp.tool()
def create_standard_service(
    service_id: int,
    service_name: str,
    component_id: int,
    service_type: str = None,
    deployment_info: dict = None,
) -> str:
    """创建标准服务

    Args:
        service_id: 服务ID
        service_name: 服务名称
        component_id: 组件ID
        service_type: 服务类型（如：redis, nebula）
        deployment_info: 部署信息（JSON对象，根据service_type验证）
    """
    db = get_db_session()
    try:
        service = StandardServiceService(db)
        svc = service.create(
            service_id=service_id,
            service_name=service_name,
            component_id=component_id,
            service_type=service_type,
            deployment_info=deployment_info,
        )
        result = {
            "id": svc.id,
            "service_id": svc.service_id,
            "service_name": svc.service_name,
            "component_id": svc.component_id,
            "service_type": svc.service_type,
            "deployment_info": svc.deployment_info,
        }
        return json.dumps(result, ensure_ascii=False, indent=2)
    except ValidationError as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    finally:
        db.close()


# ==================== 部署服务管理工具 ====================


@mcp.tool()
def get_deploy_service(id: int) -> str:
    """根据ID获取部署服务信息

    Args:
        id: 部署服务记录ID
    """
    db = get_db_session()
    try:
        service = DeployServiceService(db)
        svc = service.get_by_id(id)
        result = {
            "id": svc.id,
            "service_id": svc.service_id,
            "service_name": svc.service_name,
            "region_id": svc.region_id,
            "component_id": svc.component_id,
            "service_type": svc.service_type,
            "deployment_info": svc.deployment_info,
            "deploy_status": svc.deploy_status,
            "health_status": svc.health_status,
        }
        return json.dumps(result, ensure_ascii=False, indent=2)
    except NotFoundError as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    finally:
        db.close()


@mcp.tool()
def list_deploy_services(skip: int = 0, limit: int = 100) -> str:
    """获取部署服务列表（支持分页）

    Args:
        skip: 跳过的记录数
        limit: 返回的记录数
    """
    db = get_db_session()
    try:
        service = DeployServiceService(db)
        services = service.get_all(skip, limit)
        result = [
            {
                "id": s.id,
                "service_id": s.service_id,
                "service_name": s.service_name,
                "region_id": s.region_id,
                "service_type": s.service_type,
                "deploy_status": s.deploy_status,
            }
            for s in services
        ]
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    finally:
        db.close()


@mcp.tool()
def create_deploy_service(
    service_id: int,
    service_name: str,
    region_id: int,
    component_id: int,
    service_type: str = None,
    deployment_info: dict = None,
) -> str:
    """创建部署服务

    Args:
        service_id: 服务ID
        service_name: 服务名称
        region_id: 区域ID
        component_id: 组件ID
        service_type: 服务类型（如：redis, nebula）
        deployment_info: 部署信息（JSON对象，根据service_type验证）
    """
    db = get_db_session()
    try:
        service = DeployServiceService(db)
        svc = service.create(
            service_id=service_id,
            service_name=service_name,
            region_id=region_id,
            component_id=component_id,
            service_type=service_type,
            deployment_info=deployment_info,
        )
        result = {
            "id": svc.id,
            "service_id": svc.service_id,
            "service_name": svc.service_name,
            "region_id": svc.region_id,
            "component_id": svc.component_id,
            "service_type": svc.service_type,
            "deployment_info": svc.deployment_info,
        }
        return json.dumps(result, ensure_ascii=False, indent=2)
    except ValidationError as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    finally:
        db.close()


# ==================== 导出 HTTP App ====================

# 导出 Starlette/ASGI app 用于 uvicorn (Streamable HTTP transport)
# 使用方式: uvicorn app.mcp:http_app --host 127.0.0.1 --port 8001
http_app = mcp.streamable_http_app()

# 保持向后兼容
mcp_server = mcp._mcp_server


# ==================== 运行入口 ====================


def run_server(transport: str = "stdio"):
    """运行 MCP 服务器

    Args:
        transport: 传输类型 - "stdio", "sse", 或 "streamable-http"
    """
    mcp.run(transport=transport)
