"""CMDB MCP Server Package

使用方式:
    # stdio 传输 (Claude Desktop)
    python -m app.mcp

    # Streamable HTTP 传输 (Cline)
    uvicorn app.mcp:http_app --host 127.0.0.1 --port 8001
"""

from app.mcp.server import http_app, mcp, mcp_server, run_server

__all__ = ["mcp", "mcp_server", "http_app", "run_server"]
