"""FastAPI应用入口"""

import socket

from fastapi import FastAPI
from sqlalchemy import text
from sqlalchemy.engine.url import make_url
from strawberry.fastapi import GraphQLRouter

from app.api.graphql.schema import schema
from app.core.config import settings
from app.core.database import engine

# 创建FastAPI应用
app = FastAPI(
    title=settings.APP_NAME, version=settings.APP_VERSION, debug=settings.DEBUG
)

# 添加GraphQL路由
graphql_app = GraphQLRouter(schema)
app.include_router(graphql_app, prefix="/graphql")


@app.get("/")
async def root():
    """根路径"""
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running",
    }


@app.get("/health")
async def health():
    """健康检查"""
    return {"status": "healthy"}


@app.get("/db-test")
async def db_test():
    """数据库连接测试"""
    try:
        with engine.connect() as conn:
            result = conn.execute(text("SELECT 1"))
            return {
                "status": "success",
                "message": "数据库连接成功",
                "test_query": "SELECT 1",
                "result": result.fetchone()[0],
            }
    except Exception as e:
        return {
            "status": "failed",
            "message": f"数据库连接失败: {str(e)}",
            "error": type(e).__name__,
        }


@app.get("/net-test/mysql")
async def net_test_mysql():
    """
    纯 TCP 连通性诊断（不涉及账号密码验证）。
    用于区分：网络/防火墙/VPN 问题 vs 数据库账号/权限问题。
    """
    url = make_url(settings.DATABASE_URL)
    host = url.host
    port = url.port or 3306
    timeout = max(1, int(getattr(settings, "MYSQL_CONNECT_TIMEOUT", 5)))
    try:
        addr_info = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
        resolved = list({ai[4][0] for ai in addr_info})
    except Exception as e:
        return {
            "status": "failed",
            "stage": "dns",
            "host": host,
            "port": port,
            "message": f"DNS 解析失败: {e}",
            "error": type(e).__name__,
        }

    try:
        with socket.create_connection((host, port), timeout=timeout):
            return {
                "status": "success",
                "host": host,
                "port": port,
                "resolved_ips": resolved,
                "message": "TCP 端口可达（说明网络到 MySQL 端口是通的；后续若 db-test 失败，多半是账号/权限/SQL 层问题）",
            }
    except Exception as e:
        return {
            "status": "failed",
            "stage": "tcp_connect",
            "host": host,
            "port": port,
            "resolved_ips": resolved,
            "timeout_seconds": timeout,
            "message": f"TCP 连接失败: {e}",
            "error": type(e).__name__,
        }
