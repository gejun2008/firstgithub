"""服务服务层"""
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from app.models.service import StandardService, DeployService
from app.repositories.service_repository import StandardServiceRepository, DeployServiceRepository
from app.services.config_parser import ConfigParser
from app.core.exceptions import NotFoundError


class StandardServiceService:
    """标准服务业务逻辑层"""
    
    def __init__(self, db: Session):
        self.repository = StandardServiceRepository(db)
    
    def get_by_id(self, id: int) -> StandardService:
        """根据ID获取服务"""
        return self.repository.get_by_id_or_raise(id, "StandardService")
    
    def get_by_service_id(self, service_id: int) -> Optional[StandardService]:
        """根据service_id获取服务"""
        return self.repository.get_by_service_id(service_id)
    
    def get_all(self, skip: int = 0, limit: int = 100) -> List[StandardService]:
        """获取所有服务"""
        return self.repository.get_all(skip, limit)
    
    def create(self, service_id: int, service_name: str, component_id: int, **kwargs) -> StandardService:
        """创建服务"""
        # 验证deployment_info配置
        if 'deployment_info' in kwargs and kwargs['deployment_info']:
            kwargs['deployment_info'] = ConfigParser.parse_deployment_info(
                kwargs['deployment_info'],
                service_type=kwargs.get('service_type')
            )
        
        return self.repository.create(
            service_id=service_id,
            service_name=service_name,
            component_id=component_id,
            **kwargs
        )
    
    def update(self, id: int, **kwargs) -> StandardService:
        """更新服务"""
        # 验证deployment_info配置
        if 'deployment_info' in kwargs and kwargs['deployment_info']:
            kwargs['deployment_info'] = ConfigParser.parse_deployment_info(
                kwargs['deployment_info'],
                service_type=kwargs.get('service_type')
            )
        
        return self.repository.update(id, **kwargs)
    
    def delete(self, id: int) -> bool:
        """删除服务"""
        return self.repository.delete(id)


class DeployServiceService:
    """部署服务业务逻辑层"""
    
    def __init__(self, db: Session):
        self.repository = DeployServiceRepository(db)
    
    def get_by_id(self, id: int) -> DeployService:
        """根据ID获取部署服务"""
        return self.repository.get_by_id_or_raise(id, "DeployService")
    
    def get_by_service_id(self, service_id: int) -> Optional[DeployService]:
        """根据service_id获取部署服务"""
        return self.repository.get_by_service_id(service_id)
    
    def get_by_service_type(self, service_type: str) -> List[DeployService]:
        """根据服务类型获取部署服务列表"""
        return self.repository.get_by_service_type(service_type)
    
    def get_all(self, skip: int = 0, limit: int = 100) -> List[DeployService]:
        """获取所有部署服务"""
        return self.repository.get_all(skip, limit)
    
    def create(self, service_id: int, service_name: str, region_id: int, component_id: int, **kwargs) -> DeployService:
        """创建部署服务"""
        # 验证deployment_info配置
        if 'deployment_info' in kwargs and kwargs['deployment_info']:
            kwargs['deployment_info'] = ConfigParser.parse_deployment_info(
                kwargs['deployment_info'],
                service_type=kwargs.get('service_type')
            )
        
        return self.repository.create(
            service_id=service_id,
            service_name=service_name,
            region_id=region_id,
            component_id=component_id,
            **kwargs
        )
    
    def update(self, id: int, **kwargs) -> DeployService:
        """更新部署服务"""
        # 验证deployment_info配置
        if 'deployment_info' in kwargs and kwargs['deployment_info']:
            kwargs['deployment_info'] = ConfigParser.parse_deployment_info(
                kwargs['deployment_info'],
                service_type=kwargs.get('service_type')
            )
        
        return self.repository.update(id, **kwargs)
    
    def delete(self, id: int) -> bool:
        """删除部署服务"""
        return self.repository.delete(id)

