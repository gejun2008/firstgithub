"""产品服务层"""
from typing import List, Optional
from sqlalchemy.orm import Session
from app.models.product import Product
from app.repositories.product_repository import ProductRepository
from app.core.exceptions import NotFoundError


class ProductService:
    """产品业务逻辑层"""
    
    def __init__(self, db: Session):
        self.repository = ProductRepository(db)
    
    def get_by_id(self, id: int) -> Product:
        """根据ID获取产品"""
        return self.repository.get_by_id_or_raise(id, "Product")
    
    def get_by_product_id(self, product_id: int) -> Optional[Product]:
        """根据product_id获取产品"""
        return self.repository.get_by_product_id(product_id)
    
    def get_all(self, skip: int = 0, limit: int = 100) -> List[Product]:
        """获取所有产品"""
        return self.repository.get_all(skip, limit)
    
    def create(self, product_id: int, product_name: str, **kwargs) -> Product:
        """创建产品"""
        # 检查product_id是否已存在
        existing = self.repository.get_by_product_id(product_id)
        if existing:
            raise ValueError(f"Product with product_id {product_id} already exists")
        
        return self.repository.create(
            product_id=product_id,
            product_name=product_name,
            **kwargs
        )
    
    def update(self, id: int, **kwargs) -> Product:
        """更新产品"""
        return self.repository.update(id, **kwargs)
    
    def delete(self, id: int) -> bool:
        """删除产品"""
        return self.repository.delete(id)

