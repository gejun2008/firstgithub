"""配置解析器"""
from typing import Dict, Any, Optional
from app.services.config_schemas import (
    CONFIG_SCHEMA_REGISTRY,
    ProductType,
    DefaultConfig
)
from app.core.exceptions import ConfigValidationError


class ConfigParser:
    """配置解析和验证器"""
    
    @staticmethod
    def validate_config(
        config_data: Dict[str, Any],
        product_type: Optional[str] = None,
        service_type: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        验证并解析配置
        
        Args:
            config_data: 配置数据字典
            product_type: 产品类型
            service_type: 服务类型
            
        Returns:
            验证后的配置字典
            
        Raises:
            ConfigValidationError: 配置验证失败
        """
        # 确定配置类型
        config_type = (product_type or service_type or ProductType.DEFAULT).lower()
        
        # 获取对应的Schema类
        schema_class = CONFIG_SCHEMA_REGISTRY.get(config_type, DefaultConfig)
        
        # 使用Pydantic验证
        try:
            validated_config = schema_class(**config_data)
            return validated_config.model_dump()
        except Exception as e:
            raise ConfigValidationError(
                f"配置验证失败: {str(e)}",
                config_type=config_type
            )
    
    @staticmethod
    def parse_deployment_info(
        deployment_info: Optional[Dict[str, Any]],
        product_type: Optional[str] = None,
        service_type: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """
        解析deployment_info字段
        
        Args:
            deployment_info: 部署信息字典
            product_type: 产品类型
            service_type: 服务类型
            
        Returns:
            解析后的配置字典，如果deployment_info为None则返回None
        """
        if not deployment_info:
            return None
        
        return ConfigParser.validate_config(
            deployment_info,
            product_type,
            service_type
        )

