"""产品配置Schema定义"""
from pydantic import BaseModel, Field
from typing import List, Dict, Any
from enum import Enum


class ProductType(str, Enum):
    """产品类型枚举"""
    REDIS = "redis"
    NEBULA = "nebula"
    DEFAULT = "default"


class RedisConfig(BaseModel):
    """Redis配置Schema"""
    hostname: str = Field(..., description="Redis主机名")
    user: str = Field(..., description="用户名")
    bin_path: str = Field(..., description="二进制路径")
    config_dir: str = Field(..., description="配置目录")
    log_dir: str = Field(..., description="日志目录")
    forbidden_keywords: List[str] = Field(default_factory=list, description="禁用关键字")


class NebulaConfig(BaseModel):
    """Nebula Graph配置Schema"""
    hostname: str = Field(..., description="Nebula主机名")
    user: str = Field(..., description="用户名")
    bin_path: str = Field(..., description="二进制路径")
    config_dir: str = Field(..., description="配置目录")
    log_dir: str = Field(..., description="日志目录")
    port: str = Field(..., description="端口")
    service_names: List[str] = Field(..., description="服务名称列表")
    forbidden_keywords: List[str] = Field(default_factory=list, description="禁用关键字")


class DefaultConfig(BaseModel):
    """默认配置Schema（通用JSON）"""
    class Config:
        extra = "allow"  # 允许额外字段


# Schema注册表
CONFIG_SCHEMA_REGISTRY: Dict[str, type] = {
    ProductType.REDIS: RedisConfig,
    ProductType.NEBULA: NebulaConfig,
    ProductType.DEFAULT: DefaultConfig,
}

